 research_agent.py #RESEARCHER Research topics
 study_agent.py #STUDENT Learn + quiz
 work_agent.py #WORKER Email, calendar
 system_agent.py #IT-SUPPORT Self-heal system
 travel_agent.py #TRAVEL Book trips
 shopping_agent.py #SHOPPER Find deals
 social_agent.py #SOCIAL-MANAGER Manage socials
 finance_agent.py #CFO Manage finances
 health_agent.py #DOCTOR Health advice
 content_agent.py #CREATOR Make content
 gaming_agent.py #GAMER Coach + play
 hr_agent.py #HR Recruiting
 sales_agent.py #SALES Close deals
 marketing_agent.py #MARKETING Campaigns
 support_agent.py #SUPPORT Customer support
 data_agent.py #DATA-SCIENTIST Analyze data
 ceo_agent.py #CEO Strategic decisions
  money_making_agent.py #learns how to make active online money through data #scraping youtube videos #follows those methods smartly makes the money and deposits it into my accounts