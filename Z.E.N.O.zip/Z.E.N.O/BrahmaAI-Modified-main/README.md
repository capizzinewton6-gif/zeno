# Brahma AI - Lite
FOLLOW THIS STRICTLY

It is an agentic ai that uses gemini 2.5 flash for chatbotting and reasoning and gemini 1.5 flash for file analysis,orchestration,T2S,S2T and vision and file generation and editting.it uses omnirouter auto/best-free for fallback

## What Can Do

 system_monitor #MONITOR CPU, RAM, GPU, Temp, Battery
 computer_control #POWER Shutdown, restart, sleep, volume
 computer_settings #SETTINGS Wifi, brightness, bluetooth
 desktop #DESKTOP Wallpaper, icons, clean desktop
 network_manager #NETWORK Wifi, VPN, troubleshoot
 window_manager #WINDOWS Snap, tile, move windows
 process_manager #PROCESSES Kill, prioritize apps
 update_manager #UPDATES System/app updates
 power_manager #BATTERY Power profiles, battery saver
 disk_manager #STORAGE Cleanup, defrag, health
 printer_manager #PRINT Manage printers, print jobs
 hardware_diagnostics #DIAG Test RAM, CPU, GPU health
 bios_manager #BIOS Update BIOS, check settings
 usb_manager #USB Mount, eject, device info
 bluetooth_manager #BLUETOOTH Pair devices
 display_manager #DISPLAY Multi-monitor setup
 audio_manager #AUDIO Control sound devices
 driver_manager #DRIVERS Update drivers
 registry_cleaner #REGISTRY Clean windows registry
 terminal_manager #TERMINAL Run commands, bash, powershell
 accounts_manager #ACCOUNTS Manage users, passwords, permissions
 app_manager #APPS Open, close, install, uninstall apps
 cache_cleaner #CACHE Clear temp files, cache
 keyboard_controller #KEYBOARD Type, shortcuts, macros
 mouse_controller #MOUSE Click, move, drag, scroll
 peripheral_manager #PERIPHERALS Manage wired + wireless devices
 file_controller #FILES Create, move, copy, delete
 file_opener #SMART-OPEN Open by name
 file_processor #TRANSFORM Read, summarize, convert
 file_downloader #DOWNLOAD Download from links
 pdf_reader #PDF Extract + summarize PDFs
 backup_manager #BACKUP Auto backup to cloud
 cloud_sync #CLOUD Sync folders
 document_generator #DOCS CV, letters, proposals
 archive_manager #ZIP Zip, unzip, encrypt
 duplicate_finder #CLEANUP Find duplicates
 data_scraper #SCRAPE Scrape data from websites
 database_manager #DB Manage SQLite, MySQL, MongoDB
 excel_manager #EXCEL Read/write Excel, formulas
 csv_processor #CSV Clean, merge, analyze CSV
 image_processor #IMAGE Resize, compress, OCR
 video_processor #VIDEO Convert, compress video
 audio_processor #AUDIO Convert, trim, normalize
 version_control #VERSION Track file versions
 file_recovery #RECOVER Recover deleted files
 file_encryptor #ENCRYPT Encrypt/decrypt files
 file_comparator #DIFF Compare files
 torrent_manager #TORRENT Download torrents
 pdf_editor #PDF-EDIT Edit PDFs
 document_scanner #SCAN Scan docs to PDF
 web_search #SEARCH Google/Bing 
 weather_report #WEATHER Forecast
 internet_speed #SPEEDTEST Test internet
 ip_checker #IP Public IP info
 url_launcher #OPEN Open URLs
 research_paper_reader #PAPERS Summarize papers
 price_tracker #DEALS Track product prices
 stock_tracker #STOCKS Track stocks, crypto
 trend_analyzer #TRENDS Find trending topics
 fact_checker #VERIFY Verify claims online
 reddit_scraper #REDDIT Track subreddits
 web_scraper #GETS information from websites and webpages
  youtube_scraper #GETS information from youtube videos and channels
 youtube_research #YT-RESEARCH Find videos
 patent_search #PATENT Search patents
 translation_service #TRANSLATE  languages
 ssl_checker #SSL Check website security
 seo_auditor #SEO Audit websites
 link_checker #LINKS Find broken links
 job_board_scraper #JOBS Find job listings
 screen_recorder #RECORD Record screen
 screenshot #CAPTURE Take screenshots
 youtube_control #YT-CONTROL Play, pause, search,forward
 youtube_downloader #YT-DL Download videos
 youtube_video #YT-AI Transcript + summary
 music_player #MUSIC Play local music
 video_editor #EDIT Cut, merge, captions
 podcast_generator #PODCAST Docs → audio
 thumbnail_maker #THUMBNAIL Auto YT thumbnails
 subtitle_generator #SUBS Auto generate subtitles
 logo_generator #LOGO Brand logos
 animation_maker #ANIMATE 2D/3D animations
 sound_effect_generator #SFX  sound effects
 meme_generator #MEMES Auto memes
 gif_maker #GIF Create GIFs
 background_remover #BG-REMOVE Remove backgrounds
 voice_transcriber #TRANSCRIBE Speech to text
 karaoke_generator #KARAOKE Remove vocals
 send_message #MESSAGE Send SMS, Discord
 gmail_sender #EMAIL Send Gmail
 whatsapp_sender #WHATSAPP Send WA
 contacts #CONTACTS Manage contacts
 social_media #SOCIAL Post + interact
 instagram_downloader #IG-DL Download posts
 calendar_manager #CALENDAR Google/Outlook
 meeting_assistant #MEETING Join, record, transcribe
 email_manager #INBOX Read, draft, sort
 expense_tracker #MONEY Track spending
 note_taker #NOTES Auto meeting notes
 task_manager #TASKS To-do lists, Kanban
 project_manager #PROJECTS Manage projects, deadlines
 twitter_manager #X Post tweets, threads
 survey_creator #SURVEY Forms, polls
 crm_sender #CRM Email leads
 auto_responder #AUTO-REPLY Smart replies
 contact_enricher #ENRICH Find contact info
 voice_call_manager #CALLS Make VoIP calls
 form_filler #FORM Auto fill forms
 document_collab #COLLAB Google Docs collaboration
 reminder #REMINDER Set reminders
 proactive #PROACTIVE Act without asking
 location_tracker #LOCATION Get location
 phone_location #FIND-PHONE Find phone
 Gui_control #AUTOCLICK Click, type UI
 habit_tracker #HABITS Track habits
 anomaly_detector #ALERT Detect issues
 course_creator #COURSE Make courses
 citation_manager #CITE Manage citations
 mindmap_generator #MINDMAP Visual notes
 qr_generator #QR Generate QR
 presentation_tools #SLIDES Make slides
 google_apps #GOOGLE Docs, Sheets
 shopping_sites #SHOP Open stores
 meal_planner #FOOD Meal plans
 fitness_coach #GYM Workout + form check
 sleep_tracker #SLEEP Analyze sleep data
 water_reminder #HYDRATION Hydration reminders
 meditation_guide #MEDITATE Guided meditation
 recipe_generator #RECIPE Cook from ingredients
 travel_planner #TRIP Plan trips
 style_advisor #FASHION Outfit suggestions
 therapy_chat #THERAPY Mental health chat
 dating_coach #DATING Dating advice
 game_launcher #GAMING Launch + boost FPS
 clip_recorder #CLIPS Record highlights
 playlist_generator #PLAYLIST  music playlists
 game_coach #COACH Analyze gameplay, give tips
 game_finder #DISCOVER Find new games
 achievement_tracker #TROPHY Track achievements
 mod_manager #MODS Install game mods
 server_manager #SERVER Host game servers
 tournament_tracker #ESPORTS Track tournaments
 game_price_tracker #DEALS Track game sales
 walkthrough_generator #GUIDE Game guides
 save_manager #SAVE Backup game saves
 controller_mapper #CONTROLLER Map controls
 game_stream_recorder #STREAM-REC Record streams
 game_review_writer #REVIEW Write game reviews
 budget_manager #BUDGET Monthly budget
 crypto_trader #CRYPTO Auto trading
 business_plan_generator #PLAN Write business plans
 grant_finder #GRANT Find business grants
 document_signer #ESIGN E-sign documents
 copyright_checker #COPYRIGHT Check content
 trademark_search #TRADEMARK Check trademarks
 compliance_calendar #COMPLIANCE-CAL Track deadlines
 patent_filer #PATENT-FILE File patents
 will_generator #WILL Generate wills
 code_generator #generate complete coding source code files
 code_debugger# debugs source code
 website_builder# builds full websites
 dev_agent
 movie_downloader#downloads movies,cartoons and anime from websites
 movie_tracker#keeps track of movie episodes
 goal_manager #GOALS Track goals
 self_healing #FIX Auto fix problems
 routine_optimizer #OPTIMIZE Optimize routine
 interruption_manager #POLITE When to notify
 focus_mode #FOCUS Block distractions
 prediction_engine #PREDICT Predict what you need
 risk_assessor #RISK Assess action risks
  resource_allocator #RESOURCES Allocate CPU/RAM
 priority_manager #PRIORITY Rank tasks
 code_generator #GEN  generates v1
 function_generator #FUNC 
 class_generator #CLASS 
 ui_generator #UI 
 config_generator #CONFIG 
 script_converter #CONVERT 
 code_verifier #VERIFY -Flash double checks  output
 security_scanner #SEC Scan for vulns, injections
 test_runner #TEST Run pytest, must be 100% pass
 requirement_matcher #REQ  checks if code matches prompt
 code_refactor #REFACTOR  plans,  validates
 bug_fixer #DEBUG  reads error,  fixes, loop 3x
 code_optimizer #OPTIMIZE
 code_formatter #FORMAT 
 code_translator #TRANSLATE 
 project_scaffolder #PROJECT  plans
 file_writer #WRITE 100% LOCAL. Atomic writes + rollback
 file_reader #READ -Flash
 folder_analyzer #ANALYZE -Flash
 code_search #GREP -Flash
 codebase_indexer #INDEX  builds vector map locally
 backup_coder #BACKUP Local zip before edits
 import_resolver #IMPORTS Verify all imports exist
 code_runner #RUN Sandbox with timeout
 package_installer #PIP
 virtualenv_manager #VENV
 integration_tester #INTEGRATION Test with real DB/APIs
 online_money_maker #online money making bot
 #(
- searches through youtube
- web and youtube video scra on ways of making money online,
- implements them
- makes money fast and active
- deposites the money into my accounts  
  
   )

## Key Features

### Assistant

- Gemini-first conversation flow
- OpenRouter fallback for resilience
- Voice and text interaction
- Multi-step task execution


Z.E.N.O/
├── main.py #ENTRY Main entry point; starts AI + all daemons
├── ui.py #that ui
├── setup.py #INSTALL Installs, permissions, dependencies
├── orchestrator.py #PLANNER LLM planner breaks tasks into steps
├── smart_orchestrator.py #ROUTER Central brain routes to everything
├── chatbot.py #utilizes gemini 2.5 flash and omnirouter for fallback
├── discord_bot.py #automates discord account
├── facial_object_character_and_image_recognition.py #sees all before cam utilizes gemini 1.5 flash and omnirouter for fallback
├── gesture_util.py
├── smart_home_page.py
├── TextToSpeech.py #utilizes gemini 1.5 flash and omnirouter for fallback
├── SpeechToText.py #utilizes gemini 1.5 flash and omnirouter for fallback
├── Screen_recognition.py #sees the screen all the time utilizes gemini 1.5 flash and omnirouter for fallback
├── workspace_store.py
├── .env # where user puts all apikeys 
│
├── actions/ #  Individual tools
├── agents/  #  agents
├── ai_models/ #  AI Model wrappers
├── assets/ #  image files
├── auth/ # auth
├── config/ #11 config files
      └── models/
├── core/ #prompt.txt #SYSTEM-PROMPT Personality rules
├── dashboard/  
     └── static/  
├── integrations/ #integration files
├── memory/#memory files 
├── perception/ #  Perception modules
├── scripts/ # scripts
├── security_and_safety/ # security and safety
├── smart_agents/ #  High-level agents
├── smart_home/ #  smart home
└──  README.md




### Requirements

- Windows 10 or Windows 11
- Python 3.11 or 3.12
- Gemini API key
- omnirouter API key

### Install

Install dependencies with pip install -r requirements.txt

### Run

Start the app with python main


## Configuration

API keys are stored locally in config/api_keys.json

Discord bot settings are stored locally in config/discord_bot.json

## Project Structure

- main.py - assistant runtime and tool routing
- ui.py - desktop interface
- actions/ - automation and content-generation tools
- config/ - local settings and API key storage






