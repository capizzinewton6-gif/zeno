"""
Z.E.N.O Privacy Filter
Automatically detects and redacts sensitive information
"""

import re
import os
import json
from datetime import datetime
from typing import Dict, List, Optional, Any, Tuple, Pattern
from dataclasses import dataclass, field
from enum import Enum
import hashlib


class SensitivityLevel(Enum):
    """Levels of sensitive data"""
    PUBLIC = 0
    INTERNAL = 1
    CONFIDENTIAL = 2
    RESTRICTED = 3
    TOP_SECRET = 4


class DataType(Enum):
    """Types of sensitive data"""
    CREDIT_CARD = "credit_card"
    SSN = "ssn"
    EMAIL = "email"
    PHONE = "phone"
    API_KEY = "api_key"
    PASSWORD = "password"
    IP_ADDRESS = "ip_address"
    DATE_OF_BIRTH = "dob"
    BANK_ACCOUNT = "bank_account"
    MEDICAL_ID = "medical_id"
    PASSPORT = "passport"
    DRIVER_LICENSE = "driver_license"
    CRYPTO_WALLET = "crypto_wallet"
    PRIVATE_KEY = "private_key"
    JWT_TOKEN = "jwt_token"
    URL_CREDENTIALS = "url_credentials"
    ADDRESS = "address"
    PERSONAL_NAME = "personal_name"


@dataclass
class DetectionResult:
    """Result of sensitive data detection"""
    found: bool
    data_type: Optional[DataType]
    sensitivity: SensitivityLevel
    matches: List[Tuple[int, int, str]]  # (start, end, matched_text)
    redacted_text: Optional[str] = None


@dataclass
class PrivacyRule:
    """Rule for detecting sensitive data"""
    name: str
    data_type: DataType
    sensitivity: SensitivityLevel
    patterns: List[str]
    context_patterns: List[str] = field(default_factory=list)
    redaction_template: str = "[REDACTED]"
    validate_func: Optional[callable] = None


class PrivacyFilter:
    """
    Privacy protection system that detects, validates, and redacts
    sensitive information from text and data structures.
    """

    def __init__(self, config_path: Optional[str] = None):
        self.config_path = config_path or os.path.join(
            os.path.dirname(__file__),
            "..", "config", "privacy_rules.json"
        )
        self.rules: List[PrivacyRule] = []
        self.compiled_patterns: Dict[str, List[Pattern]] = {}
        self.redaction_cache: Dict[str, str] = {}
        self.detection_log: List[Dict] = []

        # Initialize default rules
        self._initialize_default_rules()
        self._compile_patterns()
        self._load_config()

    def _initialize_default_rules(self):
        """Initialize default privacy detection rules"""

        # Credit Card Numbers
        self.add_rule(PrivacyRule(
            name="credit_card_visa",
            data_type=DataType.CREDIT_CARD,
            sensitivity=SensitivityLevel.RESTRICTED,
            patterns=[
                r'\b4[0-9]{12}(?:[0-9]{3})?\b',
                r'\b4\d{3}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b'
            ],
            redaction_template="[CARD-REDACTED]",
            validate_func=self._validate_credit_card
        ))

        self.add_rule(PrivacyRule(
            name="credit_card_mastercard",
            data_type=DataType.CREDIT_CARD,
            sensitivity=SensitivityLevel.RESTRICTED,
            patterns=[
                r'\b5[1-5][0-9]{14}\b',
                r'\b5[1-5]\d{2}[\s-]?\d{4}[\s-]?\d{4}[\s-]?\d{4}\b'
            ],
            redaction_template="[CARD-REDACTED]",
            validate_func=self._validate_credit_card
        ))

        self.add_rule(PrivacyRule(
            name="credit_card_amex",
            data_type=DataType.CREDIT_CARD,
            sensitivity=SensitivityLevel.RESTRICTED,
            patterns=[
                r'\b3[47][0-9]{13}\b',
                r'\b3[47]\d{2}[\s-]?\d{6}[\s-]?\d{5}\b'
            ],
            redaction_template="[CARD-REDACTED]",
            validate_func=self._validate_credit_card
        ))

        # Social Security Numbers
        self.add_rule(PrivacyRule(
            name="ssn_us",
            data_type=DataType.SSN,
            sensitivity=SensitivityLevel.RESTRICTED,
            patterns=[
                r'\b\d{3}[\s-]?\d{2}[\s-]?\d{4}\b',
                r'\b\d{9}\b'
            ],
            context_patterns=[
                r'ssn', r'social.?security', r'social.?security.?number'
            ],
            redaction_template="[SSN-REDACTED]"
        ))

        # Email Addresses
        self.add_rule(PrivacyRule(
            name="email",
            data_type=DataType.EMAIL,
            sensitivity=SensitivityLevel.CONFIDENTIAL,
            patterns=[
                r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
            ],
            redaction_template="[EMAIL-REDACTED]"
        ))

        # Phone Numbers
        self.add_rule(PrivacyRule(
            name="phone_us",
            data_type=DataType.PHONE,
            sensitivity=SensitivityLevel.CONFIDENTIAL,
            patterns=[
                r'\b(\+?1[\s-]?)?\(?\d{3}\)?[\s-]?\d{3}[\s-]?\d{4}\b',
                r'\b\d{3}[-.]?\d{3}[-.]?\d{4}\b'
            ],
            redaction_template="[PHONE-REDACTED]"
        ))

        # API Keys
        self.add_rule(PrivacyRule(
            name="api_key_generic",
            data_type=DataType.API_KEY,
            sensitivity=SensitivityLevel.RESTRICTED,
            patterns=[
                r'\bapi[_-]?key[_\s]*[=:]\s*["\']?[A-Za-z0-9_-]{20,}["\']?',
                r'\b[A-Za-z0-9]{32,45}\b'
            ],
            context_patterns=[
                r'api[_-]?key', r'apikey', r'api[_-]?secret'
            ],
            redaction_template="[API-KEY-REDACTED]"
        ))

        self.add_rule(PrivacyRule(
            name="api_key_openai",
            data_type=DataType.API_KEY,
            sensitivity=SensitivityLevel.RESTRICTED,
            patterns=[
                r'\bsk-[A-Za-z0-9]{20,}T3BlbkFJ[A-Za-z0-9]{20,}\b',
                r'\bsk-[A-Za-z0-9]{48,}\b'
            ],
            redaction_template="[OPENAI-KEY-REDACTED]"
        ))

        self.add_rule(PrivacyRule(
            name="api_key_anthropic",
            data_type=DataType.API_KEY,
            sensitivity=SensitivityLevel.RESTRICTED,
            patterns=[
                r'\bsk-ant-api03-[A-Za-z0-9_-]{80,}\b'
            ],
            redaction_template="[ANTHROPIC-KEY-REDACTED]"
        ))

        # Passwords
        self.add_rule(PrivacyRule(
            name="password",
            data_type=DataType.PASSWORD,
            sensitivity=SensitivityLevel.RESTRICTED,
            patterns=[
                r'\bpassword[_\s]*[=:]\s*["\']?[^\s"\']{8,}["\']?',
                r'\bpwd[_\s]*[=:]\s*["\']?[^\s"\']{8,}["\']?',
                r'\bpass[_\s]*[=:]\s*["\']?[^\s"\']{8,}["\']?'
            ],
            redaction_template="[PASSWORD-REDACTED]"
        ))

        # IP Addresses
        self.add_rule(PrivacyRule(
            name="ipv4",
            data_type=DataType.IP_ADDRESS,
            sensitivity=SensitivityLevel.CONFIDENTIAL,
            patterns=[
                r'\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b'
            ],
            redaction_template="[IP-REDACTED]"
        ))

        self.add_rule(PrivacyRule(
            name="ipv6",
            data_type=DataType.IP_ADDRESS,
            sensitivity=SensitivityLevel.CONFIDENTIAL,
            patterns=[
                r'\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b',
                r'\b(?:[0-9a-fA-F]{1,4}:){1,7}:\b',
                r'\b(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}\b'
            ],
            redaction_template="[IP-REDACTED]"
        ))

        # Dates of Birth
        self.add_rule(PrivacyRule(
            name="dob",
            data_type=DataType.DATE_OF_BIRTH,
            sensitivity=SensitivityLevel.CONFIDENTIAL,
            patterns=[
                r'\b(?:DOB|Date of Birth|Birth Date|Birthday)[\s:]+(\d{1,2}[/\-]\d{1,2}[/\-]\d{2,4})\b',
                r'\b\d{2}[/\-]\d{2}[/\-]\d{4}\b'
            ],
            context_patterns=[
                r'dob', r'date.?of.?birth', r'birth.?date', r'birthday'
            ],
            redaction_template="[DOB-REDACTED]"
        ))

        # Bank Account Numbers
        self.add_rule(PrivacyRule(
            name="bank_account",
            data_type=DataType.BANK_ACCOUNT,
            sensitivity=SensitivityLevel.RESTRICTED,
            patterns=[
                r'\b\d{8,17}\b'
            ],
            context_patterns=[
                r'account[_\s]?number', r'bank[_\s]?account', r'routing'
            ],
            redaction_template="[ACCOUNT-REDACTED]"
        ))

        # Medical IDs
        self.add_rule(PrivacyRule(
            name="medical_id",
            data_type=DataType.MEDICAL_ID,
            sensitivity=SensitivityLevel.RESTRICTED,
            patterns=[
                r'\b[A-Z]{2}\d{6,10}\b'
            ],
            context_patterns=[
                r'medical[_\s]?id', r'patient[_\s]?id', r'mrn', r'member[_\s]?id'
            ],
            redaction_template="[MEDICAL-ID-REDACTED]"
        ))

        # Passport Numbers
        self.add_rule(PrivacyRule(
            name="passport_us",
            data_type=DataType.PASSPORT,
            sensitivity=SensitivityLevel.RESTRICTED,
            patterns=[
                r'\b[A-Z]{1,2}\d{6,9}\b'
            ],
            context_patterns=[
                r'passport', r'passport[_\s]?number'
            ],
            redaction_template="[PASSPORT-REDACTED]"
        ))

        # Driver's License
        self.add_rule(PrivacyRule(
            name="drivers_license",
            data_type=DataType.DRIVER_LICENSE,
            sensitivity=SensitivityLevel.RESTRICTED,
            patterns=[
                r'\b[A-Z]\d{7,8}\b',
                r'\b\d{3}[\s-]?\d{3}[\s-]?\d{4}\b'
            ],
            context_patterns=[
                r'driver[s]?[_\s]?license', r'dl[_\s]?number', r'license[_\s]?number'
            ],
            redaction_template="[LICENSE-REDACTED]"
        ))

        # Crypto Wallet Addresses
        self.add_rule(PrivacyRule(
            name="bitcoin_wallet",
            data_type=DataType.CRYPTO_WALLET,
            sensitivity=SensitivityLevel.RESTRICTED,
            patterns=[
                r'\b[13][a-km-zA-HJ-NP-Z1-9]{25,34}\b',
                r'\bbc1[a-z0-9]{39,59}\b'
            ],
            redaction_template="[WALLET-REDACTED]"
        ))

        self.add_rule(PrivacyRule(
            name="ethereum_wallet",
            data_type=DataType.CRYPTO_WALLET,
            sensitivity=SensitivityLevel.RESTRICTED,
            patterns=[
                r'\b0x[a-fA-F0-9]{40}\b'
            ],
            redaction_template="[WALLET-REDACTED]"
        ))

        # Private Keys
        self.add_rule(PrivacyRule(
            name="rsa_private_key",
            data_type=DataType.PRIVATE_KEY,
            sensitivity=SensitivityLevel.TOP_SECRET,
            patterns=[
                r'-----BEGIN (?:RSA |DSA |EC |OPENSSH )?PRIVATE KEY-----',
                r'-----BEGIN PGP PRIVATE KEY BLOCK-----'
            ],
            redaction_template="[PRIVATE-KEY-REDACTED]"
        ))

        # JWT Tokens
        self.add_rule(PrivacyRule(
            name="jwt_token",
            data_type=DataType.JWT_TOKEN,
            sensitivity=SensitivityLevel.RESTRICTED,
            patterns=[
                r'\beyJ[a-zA-Z0-9_-]*\.eyJ[a-zA-Z0-9_-]*\.[a-zA-Z0-9_-]*\b'
            ],
            redaction_template="[JWT-REDACTED]"
        ))

        # URL with credentials
        self.add_rule(PrivacyRule(
            name="url_credentials",
            data_type=DataType.URL_CREDENTIALS,
            sensitivity=SensitivityLevel.RESTRICTED,
            patterns=[
                r'(?:https?|ftp)://[^:]+:[^@]+@[^\s]+'
            ],
            redaction_template="[URL-CREDS-REDACTED]"
        ))

    def add_rule(self, rule: PrivacyRule):
        """Add a privacy rule"""
        self.rules.append(rule)

    def _compile_patterns(self):
        """Compile regex patterns for efficiency"""
        self.compiled_patterns = {}

        for rule in self.rules:
            compiled = []
            for pattern in rule.patterns:
                try:
                    compiled.append(re.compile(pattern, re.IGNORECASE))
                except re.error:
                    continue
            self.compiled_patterns[rule.name] = compiled

    def _validate_credit_card(self, number: str) -> bool:
        """Validate credit card number using Luhn algorithm"""
        # Remove spaces and dashes
        number = re.sub(r'[\s-]', '', number)

        if not number.isdigit():
            return False

        # Luhn algorithm
        total = 0
        reverse = number[::-1]

        for i, digit in enumerate(reverse):
            n = int(digit)
            if i % 2 == 1:
                n *= 2
                if n > 9:
                    n -= 9
            total += n

        return total % 10 == 0

    def detect(
        self,
        text: str,
        check_context: bool = True
    ) -> DetectionResult:
        """
        Detect sensitive information in text.
        Returns DetectionResult with all matches.
        """
        matches = []
        detected_types = []
        max_sensitivity = SensitivityLevel.PUBLIC
        redacted_text = text

        for rule in self.rules:
            compiled_patterns = self.compiled_patterns.get(rule.name, [])

            for pattern in compiled_patterns:
                for match in pattern.finditer(text):
                    matched_text = match.group()
                    start, end = match.span()

                    # Validate if needed
                    if rule.validate_func:
                        if not rule.validate_func(matched_text):
                            continue

                    # Check context if required
                    if check_context and rule.context_patterns:
                        context_window = text[max(0, start-50):min(len(text), end+50)]
                        context_match = False
                        for ctx_pattern in rule.context_patterns:
                            if re.search(ctx_pattern, context_window, re.IGNORECASE):
                                context_match = True
                                break
                        if not context_match:
                            continue

                    matches.append((start, end, matched_text))
                    detected_types.append(rule.data_type)

                    if rule.sensitivity.value > max_sensitivity.value:
                        max_sensitivity = rule.sensitivity

                    # Apply redaction
                    redacted_text = redacted_text.replace(
                        matched_text,
                        rule.redaction_template
                    )

        found = len(matches) > 0
        primary_type = detected_types[0] if detected_types else None

        # Log detection
        if found:
            self._log_detection(text, matches, detected_types, max_sensitivity)

        return DetectionResult(
            found=found,
            data_type=primary_type,
            sensitivity=max_sensitivity,
            matches=matches,
            redacted_text=redacted_text if found else text
        )

    def redact(
        self,
        text: str,
        replacement_map: Optional[Dict[str, str]] = None
    ) -> str:
        """
        Redact sensitive information from text.
        Optionally provide custom replacements.
        """
        result = self.detect(text)
        return result.redacted_text

    def redact_dict(
        self,
        data: Dict[str, Any],
        keys_to_check: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """
        Recursively redact sensitive data from a dictionary.
        """
        redacted = {}

        for key, value in data.items():
            if isinstance(value, str):
                # Check if key indicates sensitive data
                key_lower = key.lower()
                sensitive_keys = ['password', 'token', 'secret', 'key', 'credential', 'api']

                if any(sk in key_lower for sk in sensitive_keys):
                    redacted[key] = "[REDACTED]"
                else:
                    redacted[key] = self.redact(value)

            elif isinstance(value, dict):
                redacted[key] = self.redact_dict(value)

            elif isinstance(value, list):
                redacted[key] = [
                    self.redact_dict(item) if isinstance(item, dict)
                    else self.redact(item) if isinstance(item, str)
                    else item
                    for item in value
                ]
            else:
                redacted[key] = value

        return redacted

    def _log_detection(
        self,
        text: str,
        matches: List[Tuple[int, int, str]],
        types: List[DataType],
        sensitivity: SensitivityLevel
    ):
        """Log detection for auditing"""
        # Hash the original text for correlation without storing sensitive data
        text_hash = hashlib.sha256(text.encode()).hexdigest()[:16]

        entry = {
            "timestamp": datetime.now().isoformat(),
            "text_hash": text_hash,
            "match_count": len(matches),
            "types_detected": [t.value for t in types],
            "sensitivity_level": sensitivity.name,
            "text_preview": text[:100] + "..." if len(text) > 100 else text
        }
        self.detection_log.append(entry)

    def get_detection_log(self, limit: int = 100) -> List[Dict]:
        """Get recent detection log entries"""
        return self.detection_log[-limit:]

    def get_rules(self) -> List[Dict]:
        """Get all privacy rules"""
        return [
            {
                "name": rule.name,
                "data_type": rule.data_type.value,
                "sensitivity": rule.sensitivity.name,
                "pattern_count": len(rule.patterns),
                "redaction_template": rule.redaction_template
            }
            for rule in self.rules
        ]

    def _load_config(self):
        """Load custom privacy rules from config"""
        if os.path.exists(self.config_path):
            try:
                with open(self.config_path, 'r') as f:
                    config = json.load(f)

                for rule_data in config.get("custom_rules", []):
                    rule = PrivacyRule(
                        name=rule_data["name"],
                        data_type=DataType(rule_data["data_type"]),
                        sensitivity=SensitivityLevel(rule_data["sensitivity"]),
                        patterns=rule_data["patterns"],
                        context_patterns=rule_data.get("context_patterns", []),
                        redaction_template=rule_data.get("redaction_template", "[REDACTED]")
                    )
                    self.add_rule(rule)

                # Re-compile patterns after loading
                self._compile_patterns()

            except Exception as e:
                print(f"Error loading privacy config: {e}")

    def save_config(self):
        """Save custom rules to config file"""
        config = {"custom_rules": []}

        # Only save non-default rules (could mark defaults)
        default_names = {
            "credit_card_visa", "credit_card_mastercard", "credit_card_amex",
            "ssn_us", "email", "phone_us", "api_key_generic"
        }

        for rule in self.rules:
            if rule.name not in default_names:
                rule_data = {
                    "name": rule.name,
                    "data_type": rule.data_type.value,
                    "sensitivity": rule.sensitivity.value,
                    "patterns": rule.patterns,
                    "context_patterns": rule.context_patterns,
                    "redaction_template": rule.redaction_template
                }
                config["custom_rules"].append(rule_data)

        os.makedirs(os.path.dirname(self.config_path), exist_ok=True)
        with open(self.config_path, 'w') as f:
            json.dump(config, f, indent=2)


# Singleton instance
_privacy_filter_instance: Optional[PrivacyFilter] = None


def get_privacy_filter() -> PrivacyFilter:
    """Get or create singleton privacy filter"""
    global _privacy_filter_instance
    if _privacy_filter_instance is None:
        _privacy_filter_instance = PrivacyFilter()
    return _privacy_filter_instance


def redact_sensitive(text: str) -> str:
    """Convenience function to redact sensitive data"""
    return get_privacy_filter().redact(text)


def detect_sensitive(text: str) -> DetectionResult:
    """Convenience function to detect sensitive data"""
    return get_privacy_filter().detect(text)


if __name__ == "__main__":
    print("Z.E.N.O Privacy Filter - Testing")
    print("=" * 60)

    pf = PrivacyFilter()

    # Test various sensitive data
    test_cases = [
        "My credit card is 4532-1234-5678-9012 and my SSN is 123-45-6789",
        "Email me at john.doe@example.com or call 555-123-4567",
        "API key: sk-ant-api03-1234567890abcdefghijklmnopqrstuvwxyz",
        "Password: MySecretP@ss123",
        "Server IP: 192.168.1.100",
        "Bitcoin: 1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa",
        "JWT: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.dozjgNryP4J3jVmNHl0w5N_XgL0n3I9PlFUP0THsR8U"
    ]

    print("\nDetection and Redaction Tests:\n")
    for test in test_cases:
        result = pf.detect(test)
        print(f"Original: {test}")
        print(f"Redacted: {result.redacted_text}")
        print(f"Detected: {result.found}, Types: {[t.value for t in [result.data_type] if t]}")
        print()

    # Test dictionary redaction
    test_dict = {
        "username": "john_doe",
        "password": "super_secret_123",
        "email": "john@example.com",
        "api_key": "sk-test-1234567890",
        "metadata": {
            "ssn": "123-45-6789",
            "phone": "555-123-4567"
        }
    }

    print("\nDictionary Redaction:")
    print("Original:", json.dumps(test_dict, indent=2))
    redacted = pf.redact_dict(test_dict)
    print("Redacted:", json.dumps(redacted, indent=2))

    print("\n" + "=" * 60)
    print("Privacy Filter initialized successfully")
