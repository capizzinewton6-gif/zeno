"""
Z.E.N.O Permission Manager
Granular permission control system for all Z.E.N.O operations
"""

import os
import json
import hashlib
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Set, Any, Callable
from dataclasses import dataclass, field
from enum import Enum
import threading
from pathlib import Path


class PermissionLevel(Enum):
    """Permission levels for operations"""
    DENIED = 0
    READ_ONLY = 1
    STANDARD = 2
    ELEVATED = 3
    ADMIN = 4
    SYSTEM = 5


class PermissionCategory(Enum):
    """Categories of permissions"""
    FILE_SYSTEM = "file_system"
    NETWORK = "network"
    SYSTEM = "system"
    PROCESS = "process"
    MEMORY = "memory"
    HARDWARE = "hardware"
    AI = "ai"
    USER_DATA = "user_data"
    AUTOMATION = "automation"
    EXTERNAL_API = "external_api"


@dataclass
class Permission:
    """Individual permission definition"""
    name: str
    category: PermissionCategory
    level: PermissionLevel
    description: str
    requires_confirmation: bool = False
    max_uses_per_session: Optional[int] = None
    expires_after: Optional[timedelta] = None
    dependencies: List[str] = field(default_factory=list)


@dataclass
class PermissionGrant:
    """Active permission grant"""
    permission_name: str
    granted_at: datetime
    granted_by: str
    expires_at: Optional[datetime]
    uses_remaining: Optional[int]
    context: Dict[str, Any] = field(default_factory=dict)


class PermissionManager:
    """
    Central permission management system for Z.E.N.O.
    Handles permission requests, grants, revocations, and auditing.
    """

    def __init__(self, config_path: Optional[str] = None):
        self.config_path = config_path or os.path.join(
            os.path.dirname(__file__),
            "..", "config", "permissions.json"
        )
        self.permissions: Dict[str, Permission] = {}
        self.grants: Dict[str, PermissionGrant] = {}
        self.session_uses: Dict[str, int] = {}
        self.confirmation_callbacks: List[Callable] = []
        self.audit_log: List[Dict] = []
        self._lock = threading.RLock()

        # Initialize default permissions
        self._initialize_default_permissions()
        self._load_config()

    def _initialize_default_permissions(self):
        """Initialize the default permission set"""

        # File System Permissions
        self.register_permission(Permission(
            name="fs.read",
            category=PermissionCategory.FILE_SYSTEM,
            level=PermissionLevel.READ_ONLY,
            description="Read files from filesystem",
            requires_confirmation=False
        ))

        self.register_permission(Permission(
            name="fs.write",
            category=PermissionCategory.FILE_SYSTEM,
            level=PermissionLevel.STANDARD,
            description="Write/modify files",
            requires_confirmation=True,
            dependencies=["fs.read"]
        ))

        self.register_permission(Permission(
            name="fs.delete",
            category=PermissionCategory.FILE_SYSTEM,
            level=PermissionLevel.ELEVATED,
            description="Delete files",
            requires_confirmation=True,
            max_uses_per_session=50
        ))

        self.register_permission(Permission(
            name="fs.execute",
            category=PermissionCategory.FILE_SYSTEM,
            level=PermissionLevel.ADMIN,
            description="Execute files/programs",
            requires_confirmation=True
        ))

        self.register_permission(Permission(
            name="fs.system_access",
            category=PermissionCategory.FILE_SYSTEM,
            level=PermissionLevel.SYSTEM,
            description="Access system directories",
            requires_confirmation=True
        ))

        # Network Permissions
        self.register_permission(Permission(
            name="net.connect",
            category=PermissionCategory.NETWORK,
            level=PermissionLevel.STANDARD,
            description="Make network connections",
            requires_confirmation=False
        ))

        self.register_permission(Permission(
            name="net.listen",
            category=PermissionCategory.NETWORK,
            level=PermissionLevel.ELEVATED,
            description="Listen on network ports",
            requires_confirmation=True
        ))

        self.register_permission(Permission(
            name="net.vpn",
            category=PermissionCategory.NETWORK,
            level=PermissionLevel.ADMIN,
            description="Manage VPN connections",
            requires_confirmation=True
        ))

        self.register_permission(Permission(
            name="net.firewall",
            category=PermissionCategory.NETWORK,
            level=PermissionLevel.SYSTEM,
            description="Modify firewall rules",
            requires_confirmation=True
        ))

        # System Permissions
        self.register_permission(Permission(
            name="sys.info",
            category=PermissionCategory.SYSTEM,
            level=PermissionLevel.READ_ONLY,
            description="Read system information",
            requires_confirmation=False
        ))

        self.register_permission(Permission(
            name="sys.process",
            category=PermissionCategory.SYSTEM,
            level=PermissionLevel.STANDARD,
            description="Manage processes",
            requires_confirmation=True
        ))

        self.register_permission(Permission(
            name="sys.shutdown",
            category=PermissionCategory.SYSTEM,
            level=PermissionLevel.ADMIN,
            description="Shutdown/restart system",
            requires_confirmation=True
        ))

        self.register_permission(Permission(
            name="sys.config",
            category=PermissionCategory.SYSTEM,
            level=PermissionLevel.ELEVATED,
            description="Modify system configuration",
            requires_confirmation=True
        ))

        # Process Permissions
        self.register_permission(Permission(
            name="proc.list",
            category=PermissionCategory.PROCESS,
            level=PermissionLevel.READ_ONLY,
            description="List running processes",
            requires_confirmation=False
        ))

        self.register_permission(Permission(
            name="proc.kill",
            category=PermissionCategory.PROCESS,
            level=PermissionLevel.ELEVATED,
            description="Terminate processes",
            requires_confirmation=True,
            max_uses_per_session=20
        ))

        self.register_permission(Permission(
            name="proc.start",
            category=PermissionCategory.PROCESS,
            level=PermissionLevel.STANDARD,
            description="Start new processes",
            requires_confirmation=True
        ))

        # Hardware Permissions
        self.register_permission(Permission(
            name="hw.camera",
            category=PermissionCategory.HARDWARE,
            level=PermissionLevel.STANDARD,
            description="Access camera",
            requires_confirmation=True
        ))

        self.register_permission(Permission(
            name="hw.microphone",
            category=PermissionCategory.HARDWARE,
            level=PermissionLevel.STANDARD,
            description="Access microphone",
            requires_confirmation=True
        ))

        self.register_permission(Permission(
            name="hw.bluetooth",
            category=PermissionCategory.HARDWARE,
            level=PermissionLevel.ELEVATED,
            description="Manage Bluetooth",
            requires_confirmation=True
        ))

        self.register_permission(Permission(
            name="hw.usb",
            category=PermissionCategory.HARDWARE,
            level=PermissionLevel.ELEVATED,
            description="Manage USB devices",
            requires_confirmation=True
        ))

        # AI Permissions
        self.register_permission(Permission(
            name="ai.inference",
            category=PermissionCategory.AI,
            level=PermissionLevel.STANDARD,
            description="Run AI inference",
            requires_confirmation=False
        ))

        self.register_permission(Permission(
            name="ai.train",
            category=PermissionCategory.AI,
            level=PermissionLevel.ELEVATED,
            description="Train AI models",
            requires_confirmation=True
        ))

        self.register_permission(Permission(
            name="ai.api_external",
            category=PermissionCategory.AI,
            level=PermissionLevel.STANDARD,
            description="Use external AI APIs",
            requires_confirmation=False
        ))

        # User Data Permissions
        self.register_permission(Permission(
            name="data.read",
            category=PermissionCategory.USER_DATA,
            level=PermissionLevel.STANDARD,
            description="Read user data",
            requires_confirmation=False
        ))

        self.register_permission(Permission(
            name="data.write",
            category=PermissionCategory.USER_DATA,
            level=PermissionLevel.ELEVATED,
            description="Modify user data",
            requires_confirmation=True
        ))

        self.register_permission(Permission(
            name="data.export",
            category=PermissionCategory.USER_DATA,
            level=PermissionLevel.STANDARD,
            description="Export user data",
            requires_confirmation=True
        ))

        # Automation Permissions
        self.register_permission(Permission(
            name="auto.execute",
            category=PermissionCategory.AUTOMATION,
            level=PermissionLevel.STANDARD,
            description="Execute automation tasks",
            requires_confirmation=True
        ))

        self.register_permission(Permission(
            name="auto.schedule",
            category=PermissionCategory.AUTOMATION,
            level=PermissionLevel.ELEVATED,
            description="Schedule automation tasks",
            requires_confirmation=True
        ))

        self.register_permission(Permission(
            name="auto.unrestricted",
            category=PermissionCategory.AUTOMATION,
            level=PermissionLevel.SYSTEM,
            description="Run unrestricted automation",
            requires_confirmation=True
        ))

    def register_permission(self, permission: Permission):
        """Register a new permission"""
        with self._lock:
            self.permissions[permission.name] = permission

    def request_permission(
        self,
        permission_name: str,
        context: Optional[Dict[str, Any]] = None,
        user_id: str = "system"
    ) -> bool:
        """
        Request a permission to perform an action.
        Returns True if permission is granted, False otherwise.
        """
        with self._lock:
            if permission_name not in self.permissions:
                self._log_audit("permission_unknown", permission_name, False, context)
                return False

            permission = self.permissions[permission_name]

            # Check if already granted
            if permission_name in self.grants:
                grant = self.grants[permission_name]

                # Check expiration
                if grant.expires_at and datetime.now() > grant.expires_at:
                    del self.grants[permission_name]
                else:
                    # Check uses remaining
                    if grant.uses_remaining is not None and grant.uses_remaining <= 0:
                        del self.grants[permission_name]
                    else:
                        if grant.uses_remaining is not None:
                            grant.uses_remaining -= 1
                        self._log_audit("permission_used", permission_name, True, context)
                        return True

            # Check session usage limits
            if permission.max_uses_per_session:
                current_uses = self.session_uses.get(permission_name, 0)
                if current_uses >= permission.max_uses_per_session:
                    self._log_audit("permission_limit_reached", permission_name, False, context)
                    return False

            # Check dependencies
            for dep in permission.dependencies:
                if not self.request_permission(dep, context, user_id):
                    self._log_audit("permission_dependency_failed", permission_name, False, context)
                    return False

            # Require confirmation if needed
            if permission.requires_confirmation:
                confirmed = self._request_confirmation(permission, context)
                if not confirmed:
                    self._log_audit("permission_denied_by_user", permission_name, False, context)
                    return False

            # Grant permission
            expires_at = None
            if permission.expires_after:
                expires_at = datetime.now() + permission.expires_after

            self.grants[permission_name] = PermissionGrant(
                permission_name=permission_name,
                granted_at=datetime.now(),
                granted_by=user_id,
                expires_at=expires_at,
                uses_remaining=permission.max_uses_per_session,
                context=context or {}
            )

            self.session_uses[permission_name] = self.session_uses.get(permission_name, 0) + 1
            self._log_audit("permission_granted", permission_name, True, context)
            return True

    def _request_confirmation(
        self,
        permission: Permission,
        context: Optional[Dict[str, Any]] = None
    ) -> bool:
        """Request user confirmation for a permission"""
        for callback in self.confirmation_callbacks:
            try:
                result = callback(permission, context)
                if result:
                    return True
            except Exception as e:
                print(f"Confirmation callback error: {e}")

        # Default: prompt via console if no callbacks registered
        print(f"\n{'='*60}")
        print(f"PERMISSION REQUEST: {permission.name}")
        print(f"Description: {permission.description}")
        print(f"Level: {permission.level.name}")
        if context:
            print(f"Context: {json.dumps(context, indent=2, default=str)}")
        print(f"{'='*60}")

        response = input("Grant permission? (y/n): ").strip().lower()
        return response == 'y' or response == 'yes'

    def add_confirmation_callback(self, callback: Callable):
        """Add a callback for permission confirmations"""
        self.confirmation_callbacks.append(callback)

    def revoke_permission(self, permission_name: str):
        """Revoke a granted permission"""
        with self._lock:
            if permission_name in self.grants:
                del self.grants[permission_name]
                self._log_audit("permission_revoked", permission_name, True)

    def revoke_all_permissions(self):
        """Revoke all granted permissions"""
        with self._lock:
            self.grants.clear()
            self.session_uses.clear()
            self._log_audit("all_permissions_revoked", "all", True)

    def check_permission(self, permission_name: str) -> bool:
        """Check if a permission is currently granted"""
        with self._lock:
            if permission_name not in self.grants:
                return False

            grant = self.grants[permission_name]
            if grant.expires_at and datetime.now() > grant.expires_at:
                del self.grants[permission_name]
                return False

            if grant.uses_remaining is not None and grant.uses_remaining <= 0:
                del self.grants[permission_name]
                return False

            return True

    def get_permission_info(self, permission_name: str) -> Optional[Dict]:
        """Get detailed information about a permission"""
        with self._lock:
            if permission_name not in self.permissions:
                return None

            permission = self.permissions[permission_name]
            grant = self.grants.get(permission_name)

            return {
                "name": permission.name,
                "category": permission.category.value,
                "level": permission.level.value,
                "description": permission.description,
                "requires_confirmation": permission.requires_confirmation,
                "max_uses_per_session": permission.max_uses_per_session,
                "expires_after": str(permission.expires_after) if permission.expires_after else None,
                "dependencies": permission.dependencies,
                "is_granted": permission_name in self.grants,
                "grant_info": {
                    "granted_at": grant.granted_at.isoformat() if grant else None,
                    "granted_by": grant.granted_by if grant else None,
                    "expires_at": grant.expires_at.isoformat() if grant and grant.expires_at else None,
                    "uses_remaining": grant.uses_remaining if grant else None
                } if grant else None
            }

    def list_permissions(
        self,
        category: Optional[PermissionCategory] = None,
        granted_only: bool = False
    ) -> List[Dict]:
        """List all permissions, optionally filtered"""
        with self._lock:
            permissions = []

            for name, permission in self.permissions.items():
                if category and permission.category != category:
                    continue

                if granted_only and name not in self.grants:
                    continue

                permissions.append(self.get_permission_info(name))

            return permissions

    def _log_audit(
        self,
        action: str,
        permission_name: str,
        success: bool,
        context: Optional[Dict] = None
    ):
        """Log permission action for audit"""
        entry = {
            "timestamp": datetime.now().isoformat(),
            "action": action,
            "permission": permission_name,
            "success": success,
            "context": context or {}
        }
        self.audit_log.append(entry)

    def get_audit_log(
        self,
        permission_name: Optional[str] = None,
        since: Optional[datetime] = None,
        limit: int = 100
    ) -> List[Dict]:
        """Get audit log entries"""
        with self._lock:
            log = self.audit_log.copy()

            if permission_name:
                log = [e for e in log if e.get("permission") == permission_name]

            if since:
                log = [e for e in log if datetime.fromisoformat(e["timestamp"]) > since]

            return log[-limit:]

    def _load_config(self):
        """Load permission configuration from file"""
        if os.path.exists(self.config_path):
            try:
                with open(self.config_path, 'r') as f:
                    config = json.load(f)

                # Load custom permissions
                for perm_data in config.get("custom_permissions", []):
                    permission = Permission(
                        name=perm_data["name"],
                        category=PermissionCategory(perm_data["category"]),
                        level=PermissionLevel(perm_data["level"]),
                        description=perm_data["description"],
                        requires_confirmation=perm_data.get("requires_confirmation", False),
                        max_uses_per_session=perm_data.get("max_uses_per_session"),
                        expires_after=timedelta(seconds=perm_data["expires_after"]) if perm_data.get("expires_after") else None,
                        dependencies=perm_data.get("dependencies", [])
                    )
                    self.register_permission(permission)

                # Load pre-granted permissions
                for grant_data in config.get("granted_permissions", []):
                    expires_at = None
                    if grant_data.get("expires_at"):
                        expires_at = datetime.fromisoformat(grant_data["expires_at"])

                    self.grants[grant_data["permission"]] = PermissionGrant(
                        permission_name=grant_data["permission"],
                        granted_at=datetime.fromisoformat(grant_data["granted_at"]),
                        granted_by=grant_data.get("granted_by", "config"),
                        expires_at=expires_at,
                        uses_remaining=grant_data.get("uses_remaining"),
                        context=grant_data.get("context", {})
                    )

                print(f"Loaded permission config from {self.config_path}")

            except Exception as e:
                print(f"Error loading permission config: {e}")

    def save_config(self):
        """Save current permission state to config file"""
        with self._lock:
            config = {
                "custom_permissions": [],
                "granted_permissions": []
            }

            # Save custom permissions (non-default ones could be marked)
            for name, permission in self.permissions.items():
                perm_data = {
                    "name": permission.name,
                    "category": permission.category.value,
                    "level": permission.level.value,
                    "description": permission.description,
                    "requires_confirmation": permission.requires_confirmation,
                    "max_uses_per_session": permission.max_uses_per_session,
                    "expires_after": permission.expires_after.total_seconds() if permission.expires_after else None,
                    "dependencies": permission.dependencies
                }
                config["custom_permissions"].append(perm_data)

            # Save grants
            for name, grant in self.grants.items():
                grant_data = {
                    "permission": grant.permission_name,
                    "granted_at": grant.granted_at.isoformat(),
                    "granted_by": grant.granted_by,
                    "expires_at": grant.expires_at.isoformat() if grant.expires_at else None,
                    "uses_remaining": grant.uses_remaining,
                    "context": grant.context
                }
                config["granted_permissions"].append(grant_data)

            # Ensure config directory exists
            os.makedirs(os.path.dirname(self.config_path), exist_ok=True)

            with open(self.config_path, 'w') as f:
                json.dump(config, f, indent=2, default=str)

            print(f"Saved permission config to {self.config_path}")

    def create_permission_group(self, group_name: str, permissions: List[str]):
        """Create a group of permissions that can be granted together"""
        groups_path = os.path.join(
            os.path.dirname(self.config_path),
            "permission_groups.json"
        )

        groups = {}
        if os.path.exists(groups_path):
            with open(groups_path, 'r') as f:
                groups = json.load(f)

        groups[group_name] = permissions

        with open(groups_path, 'w') as f:
            json.dump(groups, f, indent=2)

    def grant_group(self, group_name: str, user_id: str = "system") -> bool:
        """Grant all permissions in a group"""
        groups_path = os.path.join(
            os.path.dirname(self.config_path),
            "permission_groups.json"
        )

        if not os.path.exists(groups_path):
            return False

        with open(groups_path, 'r') as f:
            groups = json.load(f)

        if group_name not in groups:
            return False

        success = True
        for perm_name in groups[group_name]:
            if not self.request_permission(perm_name, {"group": group_name}, user_id):
                success = False

        return success


# Decorator for permission checking
def require_permission(permission_name: str, context_extractor: Optional[Callable] = None):
    """
    Decorator to require a permission before executing a function.
    Usage:
        @require_permission("fs.write")
        def write_file(path, content):
            ...
    """
    def decorator(func):
        def wrapper(*args, **kwargs):
            # Get permission manager instance
            # In a real implementation, this would be injected or use a singleton
            pm = get_permission_manager()

            context = None
            if context_extractor:
                context = context_extractor(*args, **kwargs)

            if pm.request_permission(permission_name, context):
                return func(*args, **kwargs)
            else:
                raise PermissionError(f"Permission '{permission_name}' denied for {func.__name__}")

        return wrapper
    return decorator


# Singleton instance
_permission_manager_instance: Optional[PermissionManager] = None


def get_permission_manager() -> PermissionManager:
    """Get or create the singleton permission manager instance"""
    global _permission_manager_instance
    if _permission_manager_instance is None:
        _permission_manager_instance = PermissionManager()
    return _permission_manager_instance


def initialize_permission_manager(config_path: Optional[str] = None) -> PermissionManager:
    """Initialize the permission manager with a specific config"""
    global _permission_manager_instance
    _permission_manager_instance = PermissionManager(config_path)
    return _permission_manager_instance


# Example usage and testing
if __name__ == "__main__":
    print("Z.E.N.O Permission Manager - Testing")
    print("=" * 60)

    # Initialize
    pm = PermissionManager()

    # List all permissions
    print("\nRegistered Permissions:")
    for perm in pm.list_permissions():
        print(f"  {perm['name']}: {perm['description']}")

    # Test permission request
    print("\n\nTesting permission requests:")

    # Should succeed without confirmation
    result = pm.request_permission("fs.read", {"path": "/home/user/test.txt"})
    print(f"fs.read request: {result}")

    # Should require confirmation
    result = pm.request_permission("fs.delete", {"path": "/home/user/test.txt"})
    print(f"fs.delete request: {result}")

    # Check permission status
    print("\nPermission status:")
    print(f"fs.read granted: {pm.check_permission('fs.read')}")

    # Get audit log
    print("\nRecent audit entries:")
    for entry in pm.get_audit_log(limit=5):
        print(f"  {entry['timestamp']}: {entry['action']} - {entry['permission']}")

    print("\n" + "=" * 60)
    print("Permission Manager initialized successfully")
