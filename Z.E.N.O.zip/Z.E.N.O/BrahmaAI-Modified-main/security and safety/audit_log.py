"""
Z.E.N.O Audit Log System
Comprehensive logging of all actions, decisions, and system events
"""

import os
import json
import time
import threading
import hashlib
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Callable
from dataclasses import dataclass, field, asdict
from enum import Enum
import gzip
import shutil
from pathlib import Path


class AuditLevel(Enum):
    """Severity levels for audit entries"""
    DEBUG = 0
    INFO = 1
    WARNING = 2
    ERROR = 3
    CRITICAL = 4
    SECURITY = 5


class AuditCategory(Enum):
    """Categories for audit entries"""
    SYSTEM = "system"
    SECURITY = "security"
    FILE_OPERATION = "file_operation"
    NETWORK = "network"
    AI_OPERATION = "ai_operation"
    USER_ACTION = "user_action"
    AUTOMATION = "automation"
    PERMISSION = "permission"
    ERROR = "error"
    PERFORMANCE = "performance"
    DATA_ACCESS = "data_access"
    CONFIGURATION = "configuration"


@dataclass
class AuditEntry:
    """Single audit log entry"""
    timestamp: str
    level: AuditLevel
    category: AuditCategory
    action: str
    description: str
    actor: str
    target: Optional[str] = None
    outcome: str = "success"
    details: Dict[str, Any] = field(default_factory=dict)
    session_id: Optional[str] = None
    request_id: Optional[str] = None
    duration_ms: Optional[float] = None
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None
    correlation_id: Optional[str] = None


class AuditLog:
    """
    Centralized audit logging system for Z.E.N.O.
    Supports real-time streaming, persistent storage, and analysis.
    """

    def __init__(self, config_path: Optional[str] = None):
        self.config_path = config_path or os.path.join(
            os.path.dirname(__file__),
            "..", "config", "audit_config.json"
        )
        self.log_dir = os.path.join(
            os.path.dirname(__file__),
            "..", "logs", "audit"
        )

        # In-memory buffer
        self.buffer: List[AuditEntry] = []
        self.buffer_size = 1000
        self._buffer_lock = threading.RLock()

        # Subscribers for real-time updates
        self.subscribers: List[Callable[[AuditEntry], None]] = []
        self._subscriber_lock = threading.RLock()

        # Statistics
        self.stats: Dict[str, int] = {}
        self._stats_lock = threading.RLock()

        # Session tracking
        self.current_session_id: Optional[str] = None
        self.session_start: Optional[datetime] = None

        # Configuration
        self.retention_days = 30
        self.compress_after_days = 7
        self.max_file_size_mb = 50
        self.enabled = True
        self.min_level = AuditLevel.INFO

        # Initialize
        self._initialize_storage()
        self._load_config()

    def _initialize_storage(self):
        """Initialize log storage directories"""
        os.makedirs(self.log_dir, exist_ok=True)

    def _load_config(self):
        """Load audit configuration"""
        if os.path.exists(self.config_path):
            try:
                with open(self.config_path, 'r') as f:
                    config = json.load(f)

                self.retention_days = config.get("retention_days", 30)
                self.compress_after_days = config.get("compress_after_days", 7)
                self.max_file_size_mb = config.get("max_file_size_mb", 50)
                self.buffer_size = config.get("buffer_size", 1000)
                self.min_level = AuditLevel(config.get("min_level", 1))
                self.enabled = config.get("enabled", True)

            except Exception as e:
                self.log_internal(f"Failed to load audit config: {e}", AuditLevel.WARNING)

    def log(
        self,
        action: str,
        description: str,
        level: AuditLevel = AuditLevel.INFO,
        category: AuditCategory = AuditCategory.SYSTEM,
        actor: str = "system",
        target: Optional[str] = None,
        outcome: str = "success",
        details: Optional[Dict[str, Any]] = None,
        session_id: Optional[str] = None,
        request_id: Optional[str] = None,
        duration_ms: Optional[float] = None,
        ip_address: Optional[str] = None,
        correlation_id: Optional[str] = None
    ) -> str:
        """
        Log an audit entry.
        Returns the entry ID for correlation.
        """
        if not self.enabled:
            return ""

        if level.value < self.min_level.value:
            return ""

        entry = AuditEntry(
            timestamp=datetime.now().isoformat(),
            level=level,
            category=category,
            action=action,
            description=description,
            actor=actor,
            target=target,
            outcome=outcome,
            details=details or {},
            session_id=session_id or self.current_session_id,
            request_id=request_id or self._generate_request_id(),
            duration_ms=duration_ms,
            ip_address=ip_address,
            correlation_id=correlation_id
        )

        # Add to buffer
        with self._buffer_lock:
            self.buffer.append(entry)
            if len(self.buffer) >= self.buffer_size:
                self._flush_buffer()

        # Update statistics
        self._update_stats(entry)

        # Notify subscribers
        self._notify_subscribers(entry)

        return entry.request_id or ""

    def log_internal(self, message: str, level: AuditLevel = AuditLevel.INFO):
        """Log internal audit system messages"""
        entry = AuditEntry(
            timestamp=datetime.now().isoformat(),
            level=level,
            category=AuditCategory.SYSTEM,
            action="audit_internal",
            description=message,
            actor="audit_system"
        )

        with self._buffer_lock:
            self.buffer.append(entry)

    def log_file_operation(
        self,
        operation: str,
        path: str,
        actor: str = "system",
        outcome: str = "success",
        details: Optional[Dict] = None
    ):
        """Convenience method for file operations"""
        self.log(
            action=f"file_{operation}",
            description=f"File {operation}: {path}",
            level=AuditLevel.INFO,
            category=AuditCategory.FILE_OPERATION,
            actor=actor,
            target=path,
            outcome=outcome,
            details=details
        )

    def log_security_event(
        self,
        event_type: str,
        description: str,
        actor: str = "unknown",
        outcome: str = "blocked",
        details: Optional[Dict] = None
    ):
        """Convenience method for security events"""
        self.log(
            action=f"security_{event_type}",
            description=description,
            level=AuditLevel.SECURITY,
            category=AuditCategory.SECURITY,
            actor=actor,
            outcome=outcome,
            details=details
        )

    def log_permission_check(
        self,
        permission: str,
        actor: str,
        granted: bool,
        context: Optional[Dict] = None
    ):
        """Convenience method for permission checks"""
        self.log(
            action="permission_check",
            description=f"Permission '{permission}' {'granted' if granted else 'denied'}",
            level=AuditLevel.INFO if granted else AuditLevel.WARNING,
            category=AuditCategory.PERMISSION,
            actor=actor,
            target=permission,
            outcome="granted" if granted else "denied",
            details=context
        )

    def log_ai_operation(
        self,
        operation: str,
        model: str,
        actor: str = "system",
        outcome: str = "success",
        duration_ms: Optional[float] = None,
        details: Optional[Dict] = None
    ):
        """Convenience method for AI operations"""
        self.log(
            action=f"ai_{operation}",
            description=f"AI {operation} using {model}",
            level=AuditLevel.INFO,
            category=AuditCategory.AI_OPERATION,
            actor=actor,
            target=model,
            outcome=outcome,
            duration_ms=duration_ms,
            details=details
        )

    def log_error(
        self,
        error_type: str,
        message: str,
        actor: str = "system",
        details: Optional[Dict] = None
    ):
        """Convenience method for errors"""
        self.log(
            action=f"error_{error_type}",
            description=message,
            level=AuditLevel.ERROR,
            category=AuditCategory.ERROR,
            actor=actor,
            outcome="error",
            details=details
        )

    def start_session(self, session_id: Optional[str] = None) -> str:
        """Start a new audit session"""
        self.current_session_id = session_id or self._generate_session_id()
        self.session_start = datetime.now()

        self.log(
            action="session_start",
            description=f"Audit session started",
            level=AuditLevel.INFO,
            category=AuditCategory.SYSTEM,
            actor="audit_system",
            session_id=self.current_session_id
        )

        return self.current_session_id

    def end_session(self):
        """End the current audit session"""
        if self.current_session_id:
            duration = None
            if self.session_start:
                duration = (datetime.now() - self.session_start).total_seconds() * 1000

            self.log(
                action="session_end",
                description="Audit session ended",
                level=AuditLevel.INFO,
                category=AuditCategory.SYSTEM,
                actor="audit_system",
                session_id=self.current_session_id,
                duration_ms=duration
            )

            self.current_session_id = None
            self.session_start = None

    def _generate_request_id(self) -> str:
        """Generate unique request ID"""
        timestamp = str(time.time()).encode()
        random_bytes = os.urandom(4)
        return hashlib.sha256(timestamp + random_bytes).hexdigest()[:16]

    def _generate_session_id(self) -> str:
        """Generate unique session ID"""
        timestamp = str(time.time()).encode()
        random_bytes = os.urandom(8)
        return "sess_" + hashlib.sha256(timestamp + random_bytes).hexdigest()[:24]

    def _flush_buffer(self):
        """Flush buffer to persistent storage"""
        if not self.buffer:
            return

        try:
            # Determine log file
            today = datetime.now().strftime("%Y-%m-%d")
            log_file = os.path.join(self.log_dir, f"audit_{today}.jsonl")

            # Rotate if needed
            if os.path.exists(log_file):
                size_mb = os.path.getsize(log_file) / (1024 * 1024)
                if size_mb >= self.max_file_size_mb:
                    self._rotate_log(log_file)

            # Write entries
            with open(log_file, 'a') as f:
                for entry in self.buffer:
                    entry_dict = asdict(entry)
                    entry_dict['level'] = entry.level.value
                    entry_dict['category'] = entry.category.value
                    f.write(json.dumps(entry_dict) + '\n')

            # Clear buffer
            self.buffer.clear()

        except Exception as e:
            self.log_internal(f"Failed to flush audit buffer: {e}", AuditLevel.ERROR)

    def _rotate_log(self, log_file: str):
        """Rotate a full log file"""
        base, ext = os.path.splitext(log_file)
        counter = 1

        while os.path.exists(f"{base}.{counter}{ext}"):
            counter += 1

        rotated = f"{base}.{counter}{ext}"
        shutil.move(log_file, rotated)

    def _update_stats(self, entry: AuditEntry):
        """Update statistics"""
        with self._stats_lock:
            key = f"{entry.category.value}_{entry.action}"
            self.stats[key] = self.stats.get(key, 0) + 1
            self.stats[f"level_{entry.level.name}"] = self.stats.get(f"level_{entry.level.name}", 0) + 1
            self.stats["total_entries"] = self.stats.get("total_entries", 0) + 1

    def subscribe(self, callback: Callable[[AuditEntry], None]):
        """Subscribe to real-time audit updates"""
        with self._subscriber_lock:
            self.subscribers.append(callback)

    def unsubscribe(self, callback: Callable[[AuditEntry], None]):
        """Unsubscribe from real-time updates"""
        with self._subscriber_lock:
            if callback in self.subscribers:
                self.subscribers.remove(callback)

    def _notify_subscribers(self, entry: AuditEntry):
        """Notify all subscribers of new entry"""
        with self._subscriber_lock:
            for callback in self.subscribers:
                try:
                    callback(entry)
                except Exception as e:
                    self.log_internal(f"Subscriber callback error: {e}", AuditLevel.WARNING)

    def query(
        self,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        level: Optional[AuditLevel] = None,
        category: Optional[AuditCategory] = None,
        action: Optional[str] = None,
        actor: Optional[str] = None,
        target: Optional[str] = None,
        outcome: Optional[str] = None,
        session_id: Optional[str] = None,
        limit: int = 100
    ) -> List[Dict]:
        """
        Query audit log entries with filters.
        """
        results = []

        # Check buffer first
        with self._buffer_lock:
            for entry in reversed(self.buffer):
                if self._matches_filter(entry, start_time, end_time, level, category, action, actor, target, outcome, session_id):
                    results.append(asdict(entry))
                    if len(results) >= limit:
                        return results

        # Check log files
        log_files = sorted(
            [f for f in os.listdir(self.log_dir) if f.startswith("audit_") and f.endswith(".jsonl")],
            reverse=True
        )

        for log_file in log_files:
            file_path = os.path.join(self.log_dir, log_file)

            # Check if compressed
            if log_file.endswith(".gz"):
                open_func = lambda p: gzip.open(p, 'rt')
            else:
                open_func = lambda p: open(p, 'r')

            try:
                with open_func(file_path) as f:
                    for line in reversed(list(f)):
                        try:
                            entry_dict = json.loads(line.strip())
                            entry = AuditEntry(
                                timestamp=entry_dict["timestamp"],
                                level=AuditLevel(entry_dict["level"]),
                                category=AuditCategory(entry_dict["category"]),
                                action=entry_dict["action"],
                                description=entry_dict["description"],
                                actor=entry_dict["actor"],
                                target=entry_dict.get("target"),
                                outcome=entry_dict.get("outcome", "success"),
                                details=entry_dict.get("details", {}),
                                session_id=entry_dict.get("session_id"),
                                request_id=entry_dict.get("request_id"),
                                duration_ms=entry_dict.get("duration_ms"),
                                ip_address=entry_dict.get("ip_address"),
                                correlation_id=entry_dict.get("correlation_id")
                            )

                            if self._matches_filter(entry, start_time, end_time, level, category, action, actor, target, outcome, session_id):
                                results.append(entry_dict)
                                if len(results) >= limit:
                                    return results

                        except (json.JSONDecodeError, KeyError):
                            continue

            except Exception as e:
                self.log_internal(f"Error reading log file {log_file}: {e}", AuditLevel.WARNING)

        return results

    def _matches_filter(
        self,
        entry: AuditEntry,
        start_time: Optional[datetime],
        end_time: Optional[datetime],
        level: Optional[AuditLevel],
        category: Optional[AuditCategory],
        action: Optional[str],
        actor: Optional[str],
        target: Optional[str],
        outcome: Optional[str],
        session_id: Optional[str]
    ) -> bool:
        """Check if entry matches all filter criteria"""
        entry_time = datetime.fromisoformat(entry.timestamp)

        if start_time and entry_time < start_time:
            return False
        if end_time and entry_time > end_time:
            return False
        if level and entry.level != level:
            return False
        if category and entry.category != category:
            return False
        if action and not entry.action.startswith(action):
            return False
        if actor and entry.actor != actor:
            return False
        if target and entry.target != target:
            return False
        if outcome and entry.outcome != outcome:
            return False
        if session_id and entry.session_id != session_id:
            return False

        return True

    def get_statistics(self) -> Dict[str, Any]:
        """Get audit statistics"""
        with self._stats_lock:
            stats = self.stats.copy()

        stats["buffer_size"] = len(self.buffer)
        stats["subscriber_count"] = len(self.subscribers)
        stats["current_session"] = self.current_session_id

        return stats

    def cleanup_old_logs(self):
        """Remove logs older than retention period"""
        cutoff = datetime.now() - timedelta(days=self.retention_days)
        compress_cutoff = datetime.now() - timedelta(days=self.compress_after_days)

        for log_file in os.listdir(self.log_dir):
            if not log_file.startswith("audit_"):
                continue

            file_path = os.path.join(self.log_dir, log_file)

            # Extract date from filename
            try:
                date_str = log_file.replace("audit_", "").replace(".jsonl", "").replace(".gz", "")
                file_date = datetime.strptime(date_str, "%Y-%m-%d")

                # Delete if too old
                if file_date < cutoff:
                    os.remove(file_path)
                    self.log_internal(f"Deleted old log file: {log_file}", AuditLevel.INFO)

                # Compress if old enough
                elif file_date < compress_cutoff and not log_file.endswith(".gz"):
                    compressed_path = file_path + ".gz"
                    with open(file_path, 'rb') as f_in:
                        with gzip.open(compressed_path, 'wb') as f_out:
                            shutil.copyfileobj(f_in, f_out)
                    os.remove(file_path)
                    self.log_internal(f"Compressed log file: {log_file}", AuditLevel.INFO)

            except (ValueError, OSError) as e:
                self.log_internal(f"Error processing log file {log_file}: {e}", AuditLevel.WARNING)

    def export_logs(
        self,
        output_path: str,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
        format: str = "json"
    ):
        """Export logs to a file"""
        entries = self.query(start_time=start_time, end_time=end_time, limit=100000)

        if format == "json":
            with open(output_path, 'w') as f:
                json.dump(entries, f, indent=2, default=str)
        elif format == "csv":
            import csv
            with open(output_path, 'w', newline='') as f:
                if entries:
                    writer = csv.DictWriter(f, fieldnames=entries[0].keys())
                    writer.writeheader()
                    writer.writerows(entries)
        elif format == "jsonl":
            with open(output_path, 'w') as f:
                for entry in entries:
                    f.write(json.dumps(entry, default=str) + '\n')

    def save_config(self):
        """Save current configuration"""
        config = {
            "retention_days": self.retention_days,
            "compress_after_days": self.compress_after_days,
            "max_file_size_mb": self.max_file_size_mb,
            "buffer_size": self.buffer_size,
            "min_level": self.min_level.value,
            "enabled": self.enabled
        }

        os.makedirs(os.path.dirname(self.config_path), exist_ok=True)
        with open(self.config_path, 'w') as f:
            json.dump(config, f, indent=2)


# Singleton instance
_audit_log_instance: Optional[AuditLog] = None


def get_audit_log() -> AuditLog:
    """Get or create singleton audit log"""
    global _audit_log_instance
    if _audit_log_instance is None:
        _audit_log_instance = AuditLog()
    return _audit_log_instance


def audit_action(
    action: str,
    category: AuditCategory = AuditCategory.SYSTEM,
    level: AuditLevel = AuditLevel.INFO
):
    """Decorator for automatic audit logging of function calls"""
    def decorator(func):
        def wrapper(*args, **kwargs):
            audit = get_audit_log()
            start_time = time.time()
            outcome = "success"
            error = None

            try:
                result = func(*args, **kwargs)
                return result
            except Exception as e:
                outcome = "error"
                error = str(e)
                raise
            finally:
                duration = (time.time() - start_time) * 1000
                audit.log(
                    action=action,
                    description=f"Function {func.__name__} executed",
                    level=level,
                    category=category,
                    duration_ms=duration,
                    outcome=outcome,
                    details={"error": error} if error else {}
                )
        return wrapper
    return decorator


if __name__ == "__main__":
    print("Z.E.N.O Audit Log - Testing")
    print("=" * 60)

    # Initialize
    audit = AuditLog()

    # Start session
    session = audit.start_session()
    print(f"Started session: {session}")

    # Log various events
    audit.log_file_operation("read", "/home/user/test.txt", "user_001")
    audit.log_security_event("auth_failure", "Invalid login attempt", "unknown_user", "blocked")
    audit.log_permission_check("fs.write", "user_001", True)
    audit.log_ai_operation("inference", "gemini-1.5-flash", duration_ms=250.5)
    audit.log_error("runtime", "Division by zero", "calculator")

    # Query logs
    print("\nRecent audit entries:")
    for entry in audit.query(limit=5):
        print(f"  {entry['timestamp']}: {entry['action']} - {entry['description'][:50]}")

    # Get statistics
    print("\nStatistics:")
    stats = audit.get_statistics()
    print(f"  Total entries: {stats.get('total_entries', 0)}")
    print(f"  Buffer size: {stats['buffer_size']}")

    # End session
    audit.end_session()

    print("\n" + "=" * 60)
    print("Audit Log initialized successfully")
