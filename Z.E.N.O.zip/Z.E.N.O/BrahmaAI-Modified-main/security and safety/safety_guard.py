"""
Z.E.N.O Safety Guard
Protects against dangerous operations and enforces safety boundaries
"""

import os
import re
import json
import time
import threading
from datetime import datetime
from typing import Dict, List, Optional, Any, Callable, Tuple, Set
from dataclasses import dataclass, field
from enum import Enum
import hashlib
from pathlib import Path


class RiskLevel(Enum):
    """Risk levels for operations"""
    SAFE = 0
    LOW = 1
    MEDIUM = 2
    HIGH = 3
    CRITICAL = 4
    FORBIDDEN = 5


class SafetyCategory(Enum):
    """Categories of safety checks"""
    FILE_DESTRUCTION = "file_destruction"
    SYSTEM_MODIFICATION = "system_modification"
    NETWORK_EXPOSURE = "network_exposure"
    DATA_LEAK = "data_leak"
    PRIVACY_VIOLATION = "privacy_violation"
    MALWARE_RISK = "malware_risk"
    FINANCIAL_RISK = "financial_risk"
    AUTONOMOUS_ACTION = "autonomous_action"
    EXTERNAL_API = "external_api"
    CODE_EXECUTION = "code_execution"


@dataclass
class SafetyRule:
    """Safety rule definition"""
    name: str
    category: SafetyCategory
    description: str
    risk_level: RiskLevel
    patterns: List[str]  # Regex patterns to match
    exceptions: List[str] = field(default_factory=list)
    requires_confirmation: bool = True
    block_message: str = "Operation blocked by safety guard"
    auto_allow_after: Optional[int] = None  # Seconds after which to auto-allow


@dataclass
class SafetyDecision:
    """Result of a safety check"""
    allowed: bool
    risk_level: RiskLevel
    matched_rules: List[str]
    warnings: List[str]
    requires_confirmation: bool
    block_reason: Optional[str] = None
    sanitized_input: Optional[str] = None


class SafetyGuard:
    """
    Central safety system that evaluates and potentially blocks
    dangerous operations before they execute.
    """

    def __init__(self, config_path: Optional[str] = None):
        self.config_path = config_path or os.path.join(
            os.path.dirname(__file__),
            "..", "config", "safety_rules.json"
        )
        self.rules: List[SafetyRule] = []
        self.confirmation_callbacks: List[Callable] = []
        self.confirmation_cache: Dict[str, Tuple[bool, float]] = {}
        self.violation_log: List[Dict] = []
        self._lock = threading.RLock()
        self.trusted_paths: Set[str] = set()
        self.trusted_processes: Set[str] = set()

        # Initialize default rules
        self._initialize_default_rules()
        self._load_config()

    def _initialize_default_rules(self):
        """Initialize default safety rules"""

        # File Destruction Rules
        self.add_rule(SafetyRule(
            name="no_system_delete",
            category=SafetyCategory.FILE_DESTRUCTION,
            description="Block deletion of system files",
            risk_level=RiskLevel.FORBIDDEN,
            patterns=[
                r"(rm\s+-rf\s+/)",
                r"(del\s+/s\s+[A-Z]:\\Windows)",
                r"(rmdir\s+/s\s+[A-Z]:\\Windows)",
                r"(format\s+[A-Z]:)",
                r"(diskpart)",
                r"(rd\s+/s\s+/q\s+C:)",
            ],
            block_message="Destruction of system files is forbidden"
        ))

        self.add_rule(SafetyRule(
            name="no_recursive_root_delete",
            category=SafetyCategory.FILE_DESTRUCTION,
            description="Block recursive deletion from root directories",
            risk_level=RiskLevel.CRITICAL,
            patterns=[
                r"(rm\s+-rf\s+/\*)",
                r"(rm\s+-rf\s+~)",
                r"(rm\s+-rf\s+.*\*)",
                r"(del\s+/s\s+/q\s+C:\\\\\*)",
            ],
            requires_confirmation=True,
            block_message="Recursive root deletion blocked"
        ))

        self.add_rule(SafetyRule(
            name="protect_user_data",
            category=SafetyCategory.FILE_DESTRUCTION,
            description="Protect critical user data directories",
            risk_level=RiskLevel.HIGH,
            patterns=[
                r"(rm.+Documents)",
                r"(rm.+Desktop)",
                r"(rm.+Downloads)",
                r"(del.+Documents)",
                r"(rd.+Desktop)",
            ],
            requires_confirmation=True,
            block_message="Destruction of user data directories requires confirmation"
        ))

        # System Modification Rules
        self.add_rule(SafetyRule(
            name="no_registry_modification",
            category=SafetyCategory.SYSTEM_MODIFICATION,
            description="Block registry modifications",
            risk_level=RiskLevel.HIGH,
            patterns=[
                r"(reg\s+add)",
                r"(reg\s+delete)",
                r"(reg\s+import)",
                r"(RegSetValue)",
                r"(RegDeleteKey)",
            ],
            requires_confirmation=True,
            block_message="Registry modification requires confirmation"
        ))

        self.add_rule(SafetyRule(
            name="no_service_modification",
            category=SafetyCategory.SYSTEM_MODIFICATION,
            description="Block service modifications",
            risk_level=RiskLevel.HIGH,
            patterns=[
                r"(sc\s+delete)",
                r"(sc\s+stop)",
                r"(net\s+stop)",
                r"(systemctl\s+stop)",
                r"(systemctl\s+disable)",
            ],
            requires_confirmation=True
        ))

        self.add_rule(SafetyRule(
            name="no_boot_modification",
            category=SafetyCategory.SYSTEM_MODIFICATION,
            description="Block boot configuration modifications",
            risk_level=RiskLevel.CRITICAL,
            patterns=[
                r"(bcdedit)",
                r"(bootcfg)",
                r"(grub-install)",
                r"(update-grub)",
                r"(efibootmgr)",
            ],
            requires_confirmation=True,
            block_message="Boot configuration modification blocked"
        ))

        # Network Exposure Rules
        self.add_rule(SafetyRule(
            name="no_reverse_shell",
            category=SafetyCategory.NETWORK_EXPOSURE,
            description="Block potential reverse shell patterns",
            risk_level=RiskLevel.FORBIDDEN,
            patterns=[
                r"(nc\s+-e\s+/bin/bash)",
                r"(ncat.*--sh-exec)",
                r"(bash\s+-i\s+>&\s+/dev/tcp)",
                r"(python.*socket.*connect)",
                r"(powershell.*-e.*JABj)",
                r"(mkfifo.*\|.*nc)",
            ],
            block_message="Reverse shell patterns are forbidden"
        ))

        self.add_rule(SafetyRule(
            name="no_port_forwarding",
            category=SafetyCategory.NETWORK_EXPOSURE,
            description="Block port forwarding without confirmation",
            risk_level=RiskLevel.HIGH,
            patterns=[
                r"(ssh\s+-R\s+\d+)",
                r"(ssh\s+-L\s+\d+)",
                r"(netsh\s+interface\s+portproxy)",
                r"(socat.*TCP-LISTEN)",
            ],
            requires_confirmation=True
        ))

        self.add_rule(SafetyRule(
            name="no_public_exposure",
            category=SafetyCategory.NETWORK_EXPOSURE,
            description="Block binding to public interfaces",
            risk_level=RiskLevel.HIGH,
            patterns=[
                r"(0\.0\.0\.0:\d+)",
                r"(listen\(0\.0\.0\.0)",
                r"(bind.*0\.0\.0\.0)",
            ],
            requires_confirmation=True
        ))

        # Data Leak Prevention
        self.add_rule(SafetyRule(
            name="no_password_in_logs",
            category=SafetyCategory.DATA_LEAK,
            description="Block password output to logs",
            risk_level=RiskLevel.HIGH,
            patterns=[
                r"(echo.*password)",
                r"(print.*password)",
                r"(log.*password)",
                r"(console\.log.*pass)",
                r"(stdout.*secret)",
            ],
            block_message="Logging passwords is blocked"
        ))

        self.add_rule(SafetyRule(
            name="no_api_key_exposure",
            category=SafetyCategory.DATA_LEAK,
            description="Block API key exposure",
            risk_level=RiskLevel.CRITICAL,
            patterns=[
                r"(curl.*api_key=)",
                r"(wget.*api_key=)",
                r"(http.*\?api_key=)",
                r"(x-api-key:\s*[^hH])",
            ],
            requires_confirmation=True
        ))

        # Privacy Violation Rules
        self.add_rule(SafetyRule(
            name="no_keystroke_logging",
            category=SafetyCategory.PRIVACY_VIOLATION,
            description="Block keystroke logging",
            risk_level=RiskLevel.FORBIDDEN,
            patterns=[
                r"(pynput\.keyboard\.Listener)",
                r"(keyboard\.hook)",
                r"(SetWindowsHookEx.*WH_KEYBOARD)",
                r"(GetAsyncKeyState)",
                r"(keylogger)",
            ],
            block_message="Keystroke logging is forbidden"
        ))

        self.add_rule(SafetyRule(
            name="no_screen_capture_continuous",
            category=SafetyCategory.PRIVACY_VIOLATION,
            description="Block continuous screen capture",
            risk_level=RiskLevel.HIGH,
            patterns=[
                r"(mss.*while\s+True)",
                r"(pyautogui.*while\s+True)",
                r"(screen.*capture.*loop)",
            ],
            requires_confirmation=True
        ))

        # Malware Risk Rules
        self.add_rule(SafetyRule(
            name="no_executable_download",
            category=SafetyCategory.MALWARE_RISK,
            description="Block executable downloads from untrusted sources",
            risk_level=RiskLevel.HIGH,
            patterns=[
                r"(curl.*\.exe)",
                r"(wget.*\.exe)",
                r"(download.*\.bat)",
                r"(download.*\.ps1)",
            ],
            requires_confirmation=True
        ))

        self.add_rule(SafetyRule(
            name="no_encoded_execution",
            category=SafetyCategory.MALWARE_RISK,
            description="Block execution of encoded payloads",
            risk_level=RiskLevel.CRITICAL,
            patterns=[
                r"(powershell.*-enc)",
                r"(powershell.*-e\s+[A-Za-z0-9+/=]{20,})",
                r"(base64.*-d.*\|.*bash)",
                r"(python.*exec\(base64)",
            ],
            block_message="Encoded payload execution is blocked"
        ))

        # Financial Risk Rules
        self.add_rule(SafetyRule(
            name="no_unauthorized_payment",
            category=SafetyCategory.FINANCIAL_RISK,
            description="Block unauthorized payment operations",
            risk_level=RiskLevel.CRITICAL,
            patterns=[
                r"(stripe.*charge)",
                r"(paypal.*payment)",
                r"(transfer.*money)",
                r"(send.*funds)",
                r"(bank.*transfer)",
            ],
            requires_confirmation=True,
            block_message="Financial operations require explicit confirmation"
        ))

        self.add_rule(SafetyRule(
            name="no_crypto_wallet_access",
            category=SafetyCategory.FINANCIAL_RISK,
            description="Block cryptocurrency wallet access",
            risk_level=RiskLevel.HIGH,
            patterns=[
                r"(wallet.*private.*key)",
                r"(ethereum.*sign)",
                r"(bitcoin.*send)",
                r"(web3.*eth.*sendTransaction)",
            ],
            requires_confirmation=True
        ))

        # Autonomous Action Rules
        self.add_rule(SafetyRule(
            name="no_mass_email",
            category=SafetyCategory.AUTONOMOUS_ACTION,
            description="Block mass email sending",
            risk_level=RiskLevel.HIGH,
            patterns=[
                r"(send.*\d+.*emails)",
                r"(mass.*mail)",
                r"(bulk.*email)",
                r"(smtp.*while.*True)",
            ],
            requires_confirmation=True
        ))

        self.add_rule(SafetyRule(
            name="no_autonomous_posting",
            category=SafetyCategory.AUTONOMOUS_ACTION,
            description="Block autonomous social media posting",
            risk_level=RiskLevel.HIGH,
            patterns=[
                r"(twitter.*post.*loop)",
                r"(facebook.*post.*while)",
                r"(tweet.*batch)",
            ],
            requires_confirmation=True
        ))

        # Code Execution Rules
        self.add_rule(SafetyRule(
            name="no_system_call",
            category=SafetyCategory.CODE_EXECUTION,
            description="Block direct system calls",
            risk_level=RiskLevel.HIGH,
            patterns=[
                r"(subprocess\.call.*shell=True)",
                r"(os\.system\s*\()",
                r"(eval\s*\()",
                r"(exec\s*\()",
                r"(compile\s*\(.*exec)",
            ],
            requires_confirmation=True
        ))

        self.add_rule(SafetyRule(
            name="no_sudo_without_password",
            category=SafetyCategory.CODE_EXECUTION,
            description="Block sudo operations without password",
            risk_level=RiskLevel.HIGH,
            patterns=[
                r"(echo.*\|\s*sudo\s+-S)",
                r"(sudo\s+-n)",
                r"(NOPASSWD)",
            ],
            requires_confirmation=True
        ))

    def add_rule(self, rule: SafetyRule):
        """Add a safety rule"""
        with self._lock:
            self.rules.append(rule)

    def check_operation(
        self,
        operation: str,
        context: Optional[Dict[str, Any]] = None
    ) -> SafetyDecision:
        """
        Check if an operation is safe to execute.
        Returns a SafetyDecision with the result.
        """
        with self._lock:
            matched_rules = []
            warnings = []
            max_risk = RiskLevel.SAFE
            requires_confirmation = False

            for rule in self.rules:
                # Check each pattern
                for pattern in rule.patterns:
                    try:
                        if re.search(pattern, operation, re.IGNORECASE):
                            # Check exceptions
                            exception_match = False
                            for exception in rule.exceptions:
                                if re.search(exception, operation, re.IGNORECASE):
                                    exception_match = True
                                    break

                            if not exception_match:
                                matched_rules.append(rule.name)

                                if rule.risk_level.value > max_risk.value:
                                    max_risk = rule.risk_level

                                if rule.requires_confirmation:
                                    requires_confirmation = True

                                warnings.append(
                                    f"Rule '{rule.name}' matched: {rule.description}"
                                )

                                break
                    except re.error:
                        continue

            # Determine if allowed
            allowed = True
            block_reason = None

            if max_risk == RiskLevel.FORBIDDEN:
                allowed = False
                block_reason = "Operation violates forbidden safety rule"

            elif max_risk == RiskLevel.CRITICAL:
                # Check confirmation cache
                cache_key = self._get_cache_key(operation)
                if cache_key in self.confirmation_cache:
                    cached_result, cached_time = self.confirmation_cache[cache_key]
                    if cached_result and time.time() - cached_time < 300:  # 5 min cache
                        allowed = True
                    else:
                        allowed = self._request_confirmation(operation, matched_rules, max_risk)
                        self.confirmation_cache[cache_key] = (allowed, time.time())
                else:
                    allowed = self._request_confirmation(operation, matched_rules, max_risk)
                    self.confirmation_cache[cache_key] = (allowed, time.time())

                if not allowed:
                    block_reason = "User declined critical operation"

            elif requires_confirmation:
                cache_key = self._get_cache_key(operation)
                if cache_key in self.confirmation_cache:
                    cached_result, cached_time = self.confirmation_cache[cache_key]
                    if cached_result and time.time() - cached_time < 300:
                        pass  # Already confirmed
                    else:
                        self._request_confirmation(operation, matched_rules, max_risk)
                        self.confirmation_cache[cache_key] = (True, time.time())

            # Log the decision
            self._log_decision(operation, matched_rules, max_risk, allowed, block_reason)

            # Sanitize if needed
            sanitized = None
            if allowed and max_risk.value >= RiskLevel.MEDIUM.value:
                sanitized = self._sanitize_operation(operation)

            return SafetyDecision(
                allowed=allowed,
                risk_level=max_risk,
                matched_rules=matched_rules,
                warnings=warnings,
                requires_confirmation=requires_confirmation,
                block_reason=block_reason,
                sanitized_input=sanitized
            )

    def _get_cache_key(self, operation: str) -> str:
        """Generate cache key for operation"""
        return hashlib.sha256(operation.encode()).hexdigest()[:16]

    def _request_confirmation(
        self,
        operation: str,
        matched_rules: List[str],
        risk_level: RiskLevel
    ) -> bool:
        """Request user confirmation for operation"""
        for callback in self.confirmation_callbacks:
            try:
                result = callback(operation, matched_rules, risk_level)
                if result:
                    return True
            except Exception as e:
                print(f"Confirmation callback error: {e}")

        # Default console prompt
        print(f"\n{'!' * 60}")
        print(f"SAFETY WARNING - {risk_level.name} RISK OPERATION")
        print(f"{'!' * 60}")
        print(f"\nOperation: {operation[:200]}...")
        print(f"\nMatched safety rules:")
        for rule in matched_rules:
            print(f"  - {rule}")
        print(f"\n{'!' * 60}")

        response = input("Proceed with operation? (yes/no): ").strip().lower()
        return response == "yes"

    def _sanitize_operation(self, operation: str) -> str:
        """Attempt to sanitize risky parts of operation"""
        sanitized = operation

        # Replace potential password patterns
        sanitized = re.sub(
            r'(password\s*=\s*["\']?)([^"\'\s]+)',
            r'\1***REDACTED***',
            sanitized,
            flags=re.IGNORECASE
        )

        # Replace API keys
        sanitized = re.sub(
            r'(api_key\s*=\s*["\']?)([^"\'\s]+)',
            r'\1***REDACTED***',
            sanitized,
            flags=re.IGNORECASE
        )

        return sanitized

    def _log_decision(
        self,
        operation: str,
        matched_rules: List[str],
        risk_level: RiskLevel,
        allowed: bool,
        block_reason: Optional[str]
    ):
        """Log safety decision"""
        entry = {
            "timestamp": datetime.now().isoformat(),
            "operation_preview": operation[:200],
            "matched_rules": matched_rules,
            "risk_level": risk_level.name,
            "allowed": allowed,
            "block_reason": block_reason
        }
        self.violation_log.append(entry)

    def add_confirmation_callback(self, callback: Callable):
        """Add callback for confirmation requests"""
        self.confirmation_callbacks.append(callback)

    def trust_path(self, path: str):
        """Mark a path as trusted"""
        self.trusted_paths.add(os.path.abspath(path))

    def trust_process(self, process_name: str):
        """Mark a process as trusted"""
        self.trusted_processes.add(process_name.lower())

    def is_trusted_path(self, path: str) -> bool:
        """Check if path is trusted"""
        abs_path = os.path.abspath(path)
        for trusted in self.trusted_paths:
            if abs_path.startswith(trusted):
                return True
        return False

    def get_violation_log(self, limit: int = 100) -> List[Dict]:
        """Get violation log entries"""
        return self.violation_log[-limit:]

    def get_rules(self, category: Optional[SafetyCategory] = None) -> List[Dict]:
        """Get safety rules, optionally filtered"""
        rules = []
        for rule in self.rules:
            if category and rule.category != category:
                continue
            rules.append({
                "name": rule.name,
                "category": rule.category.value,
                "description": rule.description,
                "risk_level": rule.risk_level.name,
                "requires_confirmation": rule.requires_confirmation
            })
        return rules

    def _load_config(self):
        """Load configuration from file"""
        if os.path.exists(self.config_path):
            try:
                with open(self.config_path, 'r') as f:
                    config = json.load(f)

                for rule_data in config.get("custom_rules", []):
                    rule = SafetyRule(
                        name=rule_data["name"],
                        category=SafetyCategory(rule_data["category"]),
                        description=rule_data["description"],
                        risk_level=RiskLevel(rule_data["risk_level"]),
                        patterns=rule_data["patterns"],
                        exceptions=rule_data.get("exceptions", []),
                        requires_confirmation=rule_data.get("requires_confirmation", True),
                        block_message=rule_data.get("block_message", "Operation blocked")
                    )
                    self.add_rule(rule)

                for path in config.get("trusted_paths", []):
                    self.trust_path(path)

                for process in config.get("trusted_processes", []):
                    self.trust_process(process)

                print(f"Loaded safety config from {self.config_path}")

            except Exception as e:
                print(f"Error loading safety config: {e}")

    def save_config(self):
        """Save current configuration"""
        config = {
            "custom_rules": [],
            "trusted_paths": list(self.trusted_paths),
            "trusted_processes": list(self.trusted_processes)
        }

        # Save only custom rules (not defaults)
        default_names = {r.name for r in self.rules[:20]}  # Approximate

        for rule in self.rules:
            if rule.name not in default_names:
                rule_data = {
                    "name": rule.name,
                    "category": rule.category.value,
                    "description": rule.description,
                    "risk_level": rule.risk_level.value,
                    "patterns": rule.patterns,
                    "exceptions": rule.exceptions,
                    "requires_confirmation": rule.requires_confirmation,
                    "block_message": rule.block_message
                }
                config["custom_rules"].append(rule_data)

        os.makedirs(os.path.dirname(self.config_path), exist_ok=True)
        with open(self.config_path, 'w') as f:
            json.dump(config, f, indent=2)


# Singleton instance
_safety_guard_instance: Optional[SafetyGuard] = None


def get_safety_guard() -> SafetyGuard:
    """Get or create singleton safety guard"""
    global _safety_guard_instance
    if _safety_guard_instance is None:
        _safety_guard_instance = SafetyGuard()
    return _safety_guard_instance


def check_safety(operation: str, context: Optional[Dict] = None) -> SafetyDecision:
    """Convenience function to check operation safety"""
    return get_safety_guard().check_operation(operation, context)


# Decorator for automatic safety checking
def safe_operation(context_extractor: Optional[Callable] = None):
    """
    Decorator to automatically check safety of operations.
    Usage:
        @safe_operation(lambda *args: {"command": args[0]})
        def run_command(cmd):
            ...
    """
    def decorator(func):
        def wrapper(*args, **kwargs):
            sg = get_safety_guard()

            operation = ""
            if context_extractor:
                ctx = context_extractor(*args, **kwargs)
                operation = ctx.get("operation", str(ctx))
            else:
                operation = str(args) + str(kwargs)

            decision = sg.check_operation(operation)

            if decision.allowed:
                return func(*args, **kwargs)
            else:
                raise RuntimeError(f"Operation blocked: {decision.block_reason}")

        return wrapper
    return decorator


if __name__ == "__main__":
    print("Z.E.N.O Safety Guard - Testing")
    print("=" * 60)

    sg = SafetyGuard()

    # Test safe operation
    print("\nTesting safe operation:")
    decision = sg.check_operation("ls -la /home/user")
    print(f"Allowed: {decision.allowed}, Risk: {decision.risk_level.name}")

    # Test risky operation
    print("\nTesting risky operation:")
    decision = sg.check_operation("rm -rf /")
    print(f"Allowed: {decision.allowed}, Risk: {decision.risk_level.name}")
    print(f"Block reason: {decision.block_reason}")

    # Test critical operation
    print("\nTesting critical operation:")
    decision = sg.check_operation("curl http://example.com/malware.exe -o test.exe")
    print(f"Allowed: {decision.allowed}, Risk: {decision.risk_level.name}")
    print(f"Warnings: {decision.warnings}")

    print("\n" + "=" * 60)
    print("Safety Guard initialized successfully")
