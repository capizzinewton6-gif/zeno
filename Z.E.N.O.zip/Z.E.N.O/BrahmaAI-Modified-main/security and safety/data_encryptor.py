"""
Z.E.N.O Data Encryptor
File and data encryption with secure key management
"""

import os
import sys
import base64
import hashlib
import json
import time
import threading
import secrets
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Union, Tuple
from dataclasses import dataclass, field
from enum import Enum
import struct

try:
    from cryptography.fernet import Fernet
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM, ChaCha20Poly1305
    from cryptography.hazmat.primitives.asymmetric import rsa, padding
    from cryptography.hazmat.backends import default_backend
    CRYPTO_AVAILABLE = True
except ImportError:
    CRYPTO_AVAILABLE = False


class EncryptionAlgorithm(Enum):
    """Supported encryption algorithms"""
    FERNET = "fernet"
    AES_GCM = "aes-gcm"
    CHACHA20_POLY1305 = "chacha20-poly1305"
    RSA_OAEP = "rsa-oaep"
    AES_CTR = "aes-ctr"


class KeyDerivationFunction(Enum):
    """Key derivation functions"""
    PBKDF2 = "pbkdf2"
    ARGON2 = "argon2"
    SCRYPT = "scrypt"


@dataclass
class EncryptionKey:
    """Encryption key metadata"""
    key_id: str
    algorithm: EncryptionAlgorithm
    created_at: datetime
    expires_at: Optional[datetime]
    key_reference: str  # Reference to key in secure storage
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class EncryptedData:
    """Encrypted data container"""
    algorithm: EncryptionAlgorithm
    ciphertext: bytes
    nonce: Optional[bytes] = None
    key_id: Optional[str] = None
    tag: Optional[bytes] = None


class DataEncryptor:
    """
    Comprehensive data encryption system for Z.E.N.O.
    Supports multiple algorithms with secure key management.
    """

    def __init__(self, key_store_path: Optional[str] = None):
        self.key_store_path = key_store_path or os.path.join(
            os.path.dirname(__file__),
            "..", "config", "encryption_keys.json"
        )
        self.keys: Dict[str, EncryptionKey] = {}
        self._fernet_cache: Dict[str, Fernet] = {}
        self._lock = threading.RLock()
        self.default_algorithm = EncryptionAlgorithm.AES_GCM

        if not CRYPTO_AVAILABLE:
            raise ImportError("cryptography library required: pip install cryptography")

        self._load_keys()

    def _derive_key(
        self,
        password: str,
        salt: bytes,
        algorithm: EncryptionAlgorithm,
        iterations: int = 100000
    ) -> bytes:
        """Derive encryption key from password"""
        if algorithm == EncryptionAlgorithm.FERNET:
            kdf = PBKDF2HMAC(
                algorithm=hashes.SHA256(),
                length=32,
                salt=salt,
                iterations=iterations,
                backend=default_backend()
            )
            return base64.urlsafe_b64encode(kdf.derive(password.encode()))

        elif algorithm in [EncryptionAlgorithm.AES_GCM, EncryptionAlgorithm.CHACHA20_POLY1305]:
            kdf = PBKDF2HMAC(
                algorithm=hashes.SHA256(),
                length=32,
                salt=salt,
                iterations=iterations,
                backend=default_backend()
            )
            return kdf.derive(password.encode())

        else:
            raise ValueError(f"Unsupported algorithm: {algorithm}")

    def _load_keys(self):
        """Load encryption keys from secure storage"""
        if os.path.exists(self.key_store_path):
            try:
                with open(self.key_store_path, 'r') as f:
                    data = json.load(f)

                for key_id, key_data in data.get("keys", {}).items():
                    self.keys[key_id] = EncryptionKey(
                        key_id=key_id,
                        algorithm=EncryptionAlgorithm(key_data["algorithm"]),
                        created_at=datetime.fromisoformat(key_data["created_at"]),
                        expires_at=datetime.fromisoformat(key_data["expires_at"]) if key_data.get("expires_at") else None,
                        key_reference=key_data["key_reference"],
                        metadata=key_data.get("metadata", {})
                    )

            except Exception as e:
                print(f"Error loading encryption keys: {e}")

    def _save_keys(self):
        """Save encryption keys to secure storage"""
        data = {
            "keys": {}
        }

        for key_id, key in self.keys.items():
            data["keys"][key_id] = {
                "algorithm": key.algorithm.value,
                "created_at": key.created_at.isoformat(),
                "expires_at": key.expires_at.isoformat() if key.expires_at else None,
                "key_reference": key.key_reference,
                "metadata": key.metadata
            }

        os.makedirs(os.path.dirname(self.key_store_path), exist_ok=True)
        with open(self.key_store_path, 'w') as f:
            json.dump(data, f, indent=2)

    def generate_key(
        self,
        algorithm: Optional[EncryptionAlgorithm] = None,
        password: Optional[str] = None,
        expires_in_days: Optional[int] = None,
        metadata: Optional[Dict] = None
    ) -> str:
        """
        Generate a new encryption key.
        Returns key ID for reference.
        """
        algorithm = algorithm or self.default_algorithm

        if algorithm in [EncryptionAlgorithm.FERNET, EncryptionAlgorithm.AES_GCM, EncryptionAlgorithm.CHACHA20_POLY1305]:
            # Symmetric key
            if password:
                salt = secrets.token_bytes(32)
                key = self._derive_key(password, salt, algorithm)
                key_ref = base64.b64encode(salt + key).decode()
            else:
                key = secrets.token_bytes(32)
                key_ref = base64.b64encode(key).decode()

        elif algorithm == EncryptionAlgorithm.RSA_OAEP:
            # Asymmetric key pair
            private_key = rsa.generate_private_key(
                public_exponent=65537,
                key_size=2048,
                backend=default_backend()
            )
            private_pem = private_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=serialization.NoEncryption()
            )
            key_ref = base64.b64encode(private_pem).decode()

        else:
            raise ValueError(f"Unsupported algorithm: {algorithm}")

        key_id = secrets.token_hex(16)
        expires_at = None
        if expires_in_days:
            expires_at = datetime.now() + timedelta(days=expires_in_days)

        self.keys[key_id] = EncryptionKey(
            key_id=key_id,
            algorithm=algorithm,
            created_at=datetime.now(),
            expires_at=expires_at,
            key_reference=key_ref,
            metadata=metadata or {}
        )

        self._save_keys()
        return key_id

    def _get_key_bytes(self, key_id: str, password: Optional[str] = None) -> Tuple[bytes, EncryptionAlgorithm]:
        """Get raw key bytes from key ID"""
        if key_id not in self.keys:
            raise ValueError(f"Key not found: {key_id}")

        key = self.keys[key_id]
        key_ref = key.key_reference

        # Check if key has expired
        if key.expires_at and datetime.now() > key.expires_at:
            raise ValueError(f"Key expired: {key_id}")

        if key.algorithm in [EncryptionAlgorithm.FERNET, EncryptionAlgorithm.AES_GCM, EncryptionAlgorithm.CHACHA20_POLY1305]:
            # Decode from storage
            key_data = base64.b64decode(key_ref)

            if password and len(key_data) > 32:
                # Salt + derived key
                salt = key_data[:32]
                derived = self._derive_key(password, salt, key.algorithm)
                return derived, key.algorithm
            elif len(key_data) == 32:
                # Raw key
                return key_data, key.algorithm
            else:
                raise ValueError("Invalid key data")

        elif key.algorithm == EncryptionAlgorithm.RSA_OAEP:
            return key_ref.encode(), key.algorithm

        raise ValueError(f"Unsupported algorithm: {key.algorithm}")

    def encrypt(
        self,
        data: Union[str, bytes],
        key_id: Optional[str] = None,
        algorithm: Optional[EncryptionAlgorithm] = None,
        password: Optional[str] = None
    ) -> EncryptedData:
        """
        Encrypt data using specified key or algorithm.
        """
        if isinstance(data, str):
            data = data.encode('utf-8')

        algorithm = algorithm or self.default_algorithm

        if key_id:
            key_bytes, alg = self._get_key_bytes(key_id, password)
            algorithm = alg
        else:
            if not password:
                password = secrets.token_hex(16)
            salt = secrets.token_bytes(32)
            key_bytes = self._derive_key(password, salt, algorithm)
            # Include salt in ciphertext for decryption
            data = salt + data

        if algorithm == EncryptionAlgorithm.FERNET:
            if not hasattr(self, '_fernet') or (key_id and key_id not in self._fernet_cache):
                fernet = Fernet(key_bytes)
                if key_id:
                    self._fernet_cache[key_id] = fernet
            else:
                fernet = self._fernet_cache.get(key_id, Fernet(key_bytes))

            ciphertext = fernet.encrypt(data)
            return EncryptedData(
                algorithm=algorithm,
                ciphertext=ciphertext,
                key_id=key_id
            )

        elif algorithm == EncryptionAlgorithm.AES_GCM:
            nonce = secrets.token_bytes(12)
            aesgcm = AESGCM(key_bytes)
            ciphertext = aesgcm.encrypt(nonce, data, None)
            return EncryptedData(
                algorithm=algorithm,
                ciphertext=ciphertext,
                nonce=nonce,
                key_id=key_id
            )

        elif algorithm == EncryptionAlgorithm.CHACHA20_POLY1305:
            nonce = secrets.token_bytes(12)
            chacha = ChaCha20Poly1305(key_bytes)
            ciphertext = chacha.encrypt(nonce, data, None)
            return EncryptedData(
                algorithm=algorithm,
                ciphertext=ciphertext,
                nonce=nonce,
                key_id=key_id
            )

        elif algorithm == EncryptionAlgorithm.RSA_OAEP:
            private_pem = base64.b64decode(key_bytes)
            private_key = serialization.load_pem_private_key(
                private_pem,
                password=None,
                backend=default_backend()
            )
            public_key = private_key.public_key()

            ciphertext = public_key.encrypt(
                data,
                padding.OAEP(
                    mgf=padding.MGF1(algorithm=hashes.SHA256()),
                    algorithm=hashes.SHA256(),
                    label=None
                )
            )
            return EncryptedData(
                algorithm=algorithm,
                ciphertext=ciphertext,
                key_id=key_id
            )

        else:
            raise ValueError(f"Unsupported algorithm: {algorithm}")

    def decrypt(
        self,
        encrypted_data: EncryptedData,
        key_id: Optional[str] = None,
        password: Optional[str] = None
    ) -> bytes:
        """Decrypt encrypted data"""
        algorithm = encrypted_data.algorithm

        if key_id:
            key_bytes, alg = self._get_key_bytes(key_id, password)
            algorithm = alg
        elif encrypted_data.key_id:
            key_bytes, alg = self._get_key_bytes(encrypted_data.key_id, password)
            algorithm = alg
        else:
            raise ValueError("No key specified")

        if algorithm == EncryptionAlgorithm.FERNET:
            fernet = Fernet(key_bytes)
            return fernet.decrypt(encrypted_data.ciphertext)

        elif algorithm == EncryptionAlgorithm.AES_GCM:
            aesgcm = AESGCM(key_bytes)
            return aesgcm.decrypt(encrypted_data.nonce, encrypted_data.ciphertext, None)

        elif algorithm == EncryptionAlgorithm.CHACHA20_POLY1305:
            chacha = ChaCha20Poly1305(key_bytes)
            return chacha.decrypt(encrypted_data.nonce, encrypted_data.ciphertext, None)

        elif algorithm == EncryptionAlgorithm.RSA_OAEP:
            private_pem = base64.b64decode(key_bytes)
            private_key = serialization.load_pem_private_key(
                private_pem,
                password=None,
                backend=default_backend()
            )

            return private_key.decrypt(
                encrypted_data.ciphertext,
                padding.OAEP(
                    mgf=padding.MGF1(algorithm=hashes.SHA256()),
                    algorithm=hashes.SHA256(),
                    label=None
                )
            )

        raise ValueError(f"Unsupported algorithm: {algorithm}")

    def encrypt_file(
        self,
        input_path: str,
        output_path: Optional[str] = None,
        key_id: Optional[str] = None,
        algorithm: Optional[EncryptionAlgorithm] = None,
        password: Optional[str] = None,
        chunk_size: int = 1024 * 1024
    ) -> str:
        """
        Encrypt a file with streaming for large files.
        Returns path to encrypted file.
        """
        if output_path is None:
            output_path = input_path + ".enc"

        algorithm = algorithm or self.default_algorithm

        if algorithm in [EncryptionAlgorithm.AES_GCM, EncryptionAlgorithm.CHACHA20_POLY1305]:
            # Stream encryption
            nonce = secrets.token_bytes(12 if algorithm == EncryptionAlgorithm.AES_GCM else 12)

            if algorithm == EncryptionAlgorithm.AES_GCM:
                cipher = AESGCM(self._get_key_bytes(key_id or "", password)[0] if key_id else secrets.token_bytes(32))
            else:
                cipher = ChaCha20Poly1305(self._get_key_bytes(key_id or "", password)[0] if key_id else secrets.token_bytes(32))

            # Get file size
            file_size = os.path.getsize(input_path)

            with open(input_path, 'rb') as fin:
                with open(output_path, 'wb') as fout:
                    # Write header: algorithm, nonce, file_size
                    header = json.dumps({
                        "algorithm": algorithm.value,
                        "nonce": base64.b64encode(nonce).decode(),
                        "file_size": file_size,
                        "key_id": key_id
                    }).encode()
                    fout.write(struct.pack('I', len(header)))
                    fout.write(header)

                    # Encrypt chunks
                    ciphertext = b''
                    while True:
                        chunk = fin.read(chunk_size)
                        if not chunk:
                            break
                        ciphertext += cipher.encrypt(nonce, chunk, None)

                    fout.write(ciphertext)

            return output_path

        else:
            # Read entire file for Fernet/RSA
            with open(input_path, 'rb') as f:
                data = f.read()

            encrypted = self.encrypt(data, key_id, algorithm, password)

            with open(output_path, 'wb') as f:
                # Write header
                header = json.dumps({
                    "algorithm": encrypted.algorithm.value,
                    "key_id": encrypted.key_id
                }).encode()
                f.write(struct.pack('I', len(header)))
                f.write(header)
                f.write(encrypted.ciphertext)

            return output_path

    def decrypt_file(
        self,
        input_path: str,
        output_path: Optional[str] = None,
        key_id: Optional[str] = None,
        password: Optional[str] = None
    ) -> str:
        """Decrypt an encrypted file"""
        if output_path is None:
            output_path = input_path.replace(".enc", ".dec")

        with open(input_path, 'rb') as fin:
            # Read header
            header_len = struct.unpack('I', fin.read(4))[0]
            header = json.loads(fin.read(header_len).decode())

            algorithm = EncryptionAlgorithm(header["algorithm"])
            file_key_id = header.get("key_id", key_id)

            if algorithm in [EncryptionAlgorithm.AES_GCM, EncryptionAlgorithm.CHACHA20_POLY1305]:
                nonce = base64.b64decode(header["nonce"])

                if algorithm == EncryptionAlgorithm.AES_GCM:
                    cipher = AESGCM(self._get_key_bytes(file_key_id, password)[0])
                else:
                    cipher = ChaCha20Poly1305(self._get_key_bytes(file_key_id, password)[0])

                # Read and decrypt all at once (for simplicity)
                ciphertext = fin.read()
                plaintext = cipher.decrypt(nonce, ciphertext, None)

                with open(output_path, 'wb') as fout:
                    fout.write(plaintext)

            else:
                ciphertext = fin.read()
                encrypted = EncryptedData(
                    algorithm=algorithm,
                    ciphertext=ciphertext,
                    key_id=file_key_id
                )
                plaintext = self.decrypt(encrypted, key_id, password)

                with open(output_path, 'wb') as fout:
                    fout.write(plaintext)

        return output_path

    def encrypt_dict(
        self,
        data: Dict[str, Any],
        key_id: Optional[str] = None,
        algorithm: Optional[EncryptionAlgorithm] = None,
        password: Optional[str] = None
    ) -> str:
        """Encrypt a dictionary to a base64 string"""
        json_data = json.dumps(data)
        encrypted = self.encrypt(json_data, key_id, algorithm, password)
        return base64.b64encode(encrypted.ciphertext).decode()

    def decrypt_dict(
        self,
        encrypted_str: str,
        key_id: Optional[str] = None,
        password: Optional[str] = None
    ) -> Dict[str, Any]:
        """Decrypt a base64 encrypted string back to dictionary"""
        ciphertext = base64.b64decode(encrypted_str)
        encrypted = EncryptedData(
            algorithm=self.default_algorithm,
            ciphertext=ciphertext,
            key_id=key_id
        )
        decrypted = self.decrypt(encrypted, key_id, password)
        return json.loads(decrypted.decode())

    def hash_data(
        self,
        data: Union[str, bytes],
        algorithm: str = "sha256"
    ) -> str:
        """Create a hash of data"""
        if isinstance(data, str):
            data = data.encode('utf-8')

        if algorithm == "sha256":
            return hashlib.sha256(data).hexdigest()
        elif algorithm == "sha512":
            return hashlib.sha512(data).hexdigest()
        elif algorithm == "blake2b":
            return hashlib.blake2b(data).hexdigest()
        elif algorithm == "blake2s":
            return hashlib.blake2s(data).hexdigest()
        else:
            raise ValueError(f"Unknown hash algorithm: {algorithm}")

    def hash_password(self, password: str, salt: Optional[bytes] = None) -> Tuple[str, str]:
        """Hash a password with salt"""
        if salt is None:
            salt = secrets.token_bytes(32)

        key = self._derive_key(password, salt, EncryptionAlgorithm.AES_GCM)
        hash_value = hashlib.sha256(key + salt).hexdigest()

        return hash_value, base64.b64encode(salt).decode()

    def verify_password(self, password: str, hash_value: str, salt: str) -> bool:
        """Verify a password against a hash"""
        salt_bytes = base64.b64decode(salt)
        computed_hash, _ = self.hash_password(password, salt_bytes)
        return secrets.compare_digest(computed_hash, hash_value)

    def get_key_info(self, key_id: str) -> Optional[Dict]:
        """Get information about a key"""
        if key_id not in self.keys:
            return None

        key = self.keys[key_id]
        return {
            "key_id": key.key_id,
            "algorithm": key.algorithm.value,
            "created_at": key.created_at.isoformat(),
            "expires_at": key.expires_at.isoformat() if key.expires_at else None,
            "is_expired": key.expires_at and datetime.now() > key.expires_at if key.expires_at else False,
            "metadata": key.metadata
        }

    def list_keys(self) -> List[Dict]:
        """List all encryption keys"""
        return [self.get_key_info(key_id) for key_id in self.keys.keys()]

    def revoke_key(self, key_id: str):
        """Revoke/delete an encryption key"""
        if key_id in self.keys:
            del self.keys[key_id]
            if key_id in self._fernet_cache:
                del self._fernet_cache[key_id]
            self._save_keys()

    def rotate_key(self, old_key_id: str, password: Optional[str] = None) -> str:
        """
        Rotate to a new key, re-encrypting data with old key.
        Returns new key ID.
        """
        old_key = self.keys.get(old_key_id)
        if not old_key:
            raise ValueError(f"Key not found: {old_key_id}")

        # Generate new key
        new_key_id = self.generate_key(
            algorithm=old_key.algorithm,
            password=password,
            metadata=old_key.metadata
        )

        return new_key_id


# Singleton
_encryptor_instance: Optional[DataEncryptor] = None


def get_encryptor() -> DataEncryptor:
    """Get or create singleton encryptor"""
    global _encryptor_instance
    if _encryptor_instance is None:
        _encryptor_instance = DataEncryptor()
    return _encryptor_instance


if __name__ == "__main__":
    print("Z.E.N.O Data Encryptor - Testing")
    print("=" * 60)

    # Initialize
    encryptor = DataEncryptor()

    # Generate key
    key_id = encryptor.generate_key(EncryptionAlgorithm.AES_GCM)
    print(f"Generated key: {key_id}")

    # Test encryption
    test_data = "Hello, Z.E.N.O! This is a secret message."
    print(f"Original: {test_data}")

    encrypted = encryptor.encrypt(test_data, key_id)
    print(f"Encrypted (base64): {base64.b64encode(encrypted.ciphertext).decode()[:50]}...")

    decrypted = encryptor.decrypt(encrypted, key_id)
    print(f"Decrypted: {decrypted}")

    # Test dictionary encryption
    test_dict = {"username": "admin", "password": "secret123", "api_key": "sk-12345"}
    print(f"\nDict encryption test:")
    enc_dict = encryptor.encrypt_dict(test_dict, key_id)
    dec_dict = encryptor.decrypt_dict(enc_dict, key_id)
    print(f"Original: {test_dict}")
    print(f"Decrypted: {dec_dict}")

    # Test password hashing
    password = "MySecureP@ssw0rd!"
    hash_val, salt = encryptor.hash_password(password)
    print(f"\nPassword hash test:")
    print(f"Verified: {encryptor.verify_password(password, hash_val, salt)}")

    # List keys
    print("\nKey list:")
    for key in encryptor.list_keys():
        print(f"  {key['key_id']}: {key['algorithm']}")

    print("\n" + "=" * 60)
    print("Data Encryptor initialized successfully")