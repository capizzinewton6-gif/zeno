Z.E.N.O/
├── main.py #ENTRY Main entry point; starts AI + all daemons
├── ui.py #that ui
├── setup.py #INSTALL Installs, permissions, dependencies
├── orchestrator.py #PLANNER LLM planner breaks tasks into steps
├── smart_orchestrator.py #ROUTER Central brain routes to everything
├── chatbot.py #utilizes gemini 2.5 flash and omnirouter for fallback
├── discord_bot.py #automates discord account
├── facial_object_character_and_image_recognition.py #sees all before cam utilizes gemini 1.5 flash and omnirouter for fallback
├── gesture_util.py
├── smart_home_page.py
├── TextToSpeech.py #utilizes gemini 1.5 flash and omnirouter for fallback
├── SpeechToText.py #utilizes gemini 1.5 flash and omnirouter for fallback
├── Screen_recognition.py #sees the screen all the time utilizes gemini 1.5 flash and omnirouter for fallback
├── workspace_store.py
├── .env # where user puts all apikeys 
│
├── actions/ #  Individual tools
├── agents/  #  agents
├── ai_models/ #  AI Model wrappers
├── assets/ #  image files
├── auth/ # auth
├── config/ #11 config files
      └── models/
├── core/ #prompt.txt #SYSTEM-PROMPT Personality rules
├── dashboard/  
     └── static/  
├── integrations/ #integration files
├── memory/#memory files 
├── perception/ #  Perception modules
├── scripts/ # scripts
├── security_and_safety/ # security and safety
├── smart_agents/ #  High-level agents
├── smart_home/ #  smart home
├── README.md
└── Z.E.N.O structure readme.md

   