"""
chat_page.py  –  Brahma AI Chat Screen
=======================================
Drop-in QWidget that handles:
  • Text conversations  (QLineEdit → send)
  • Audio conversations (mic button → recording indicator → transcribed text shown)
  • Rich-content cards  (images, video embeds, web search results)
  • Clean AI-vs-user bubble distinction  (no EventCard in this view)

Wire-up in MainWindow / BrahmaUI:
  1.  Import ChatPage and ChatInputBar from this file.
  2.  Add ChatPage to the center QStackedWidget.
  3.  Connect ChatPage.command_submitted  → your existing on_text_command.
  4.  Connect ChatPage.mic_state_changed  → your STT controller.
  5.  Call chatpage.push_message(...)     to inject messages from the backend.
  6.  Remove the command input row from the dashboard panel
      (delete `self._command_panel` and `self._build_command_row()` usage there).
"""

from __future__ import annotations

import html as html_lib
import math
import re
import time
from pathlib import Path
from typing import Any

from PyQt6.QtCore import (
    QEasingCurve, QPropertyAnimation, QRectF, QSize, Qt, QTimer, QUrl,
    pyqtProperty, pyqtSignal,
)
from PyQt6.QtGui import (
    QBrush, QColor, QFont, QIcon, QLinearGradient, QPainter, QPen, QPixmap,
    QRadialGradient, QTextOption,
)
from PyQt6.QtWidgets import (
    QFrame, QGraphicsDropShadowEffect, QHBoxLayout, QLabel, QLineEdit,
    QProgressBar, QPushButton, QScrollArea, QSizePolicy, QStackedWidget,
    QTextBrowser, QTextEdit, QVBoxLayout, QWidget,
)


# ---------------------------------------------------------------------------
# Colour palette (mirrors C class in ui.py – keep in sync)
# ---------------------------------------------------------------------------
class _C:
    BG       = "#020305"
    PANEL    = "#07080b"
    PANEL2   = "#0d0f14"
    BORDER   = "#22252d"
    BORDER_B = "#41454f"
    PRI      = "#ff4545"
    PRI_DIM  = "#ff7777"
    PRI_GHO  = "#2a0b0d"
    GREEN    = "#37ff5f"
    RED      = "#ff4545"
    TEXT     = "#f4f6f8"
    TEXT_DIM = "#8e949d"
    TEXT_MED = "#c5cad2"
    WHITE    = "#ffffff"


def _qc(hex_color: str, alpha: int = 255) -> QColor:
    c = QColor(hex_color)
    c.setAlpha(alpha)
    return c


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def _fmt_stamp(ts=None) -> str:
    try:
        from datetime import datetime
        if ts is None:
            return datetime.now().strftime("%H:%M")
        t = float(ts)
        if t > 1e10:
            t /= 1000
        return datetime.fromtimestamp(t).strftime("%H:%M")
    except Exception:
        return ""


def _md_to_html(text: str, role: str = "assistant") -> str:
    safe = html_lib.escape(text or "")
    safe = safe.replace("\r\n", "\n").replace("\r", "\n")

    def _code_block(m):
        code = html_lib.escape(m.group(1).rstrip("\n"))
        return (
            '<pre style="margin:8px 0;padding:10px 12px;border-radius:10px;'
            'background:rgba(0,0,0,.38);color:#f4f6f8;border:1px solid rgba(255,255,255,.08);">'
            f"<code>{code}</code></pre>"
        )

    safe = re.sub(r"```(?:[\w+-]+\n)?(.*?)```", _code_block, safe, flags=re.S)
    safe = re.sub(
        r"`([^`]+)`",
        r'<code style="padding:1px 5px;border-radius:5px;'
        r'background:rgba(255,255,255,.08);color:#fff;">\1</code>',
        safe,
    )
    safe = re.sub(r"(?m)^###\s(.+)$", r'<h3 style="margin:8px 0 4px">\1</h3>', safe)
    safe = re.sub(r"(?m)^##\s(.+)$",  r'<h2 style="margin:8px 0 6px">\1</h2>', safe)
    safe = re.sub(r"(?m)^#\s(.+)$",   r'<h1 style="margin:8px 0 6px">\1</h1>', safe)
    safe = safe.replace("\n", "<br>")
    color = _C.WHITE if role == "assistant" else _C.TEXT
    return (
        f'<div style="color:{color};font-size:12px;line-height:1.5;white-space:normal;">'
        f"{safe}</div>"
    )


# ---------------------------------------------------------------------------
# Rich-content cards
# ---------------------------------------------------------------------------
class _ImageCard(QFrame):
    """Inline image display."""

    def __init__(self, url: str, caption: str = "", parent=None):
        super().__init__(parent)
        self.setObjectName("ImageCard")
        self.setStyleSheet(
            "QFrame#ImageCard{"
            "background:rgba(10,11,14,230);"
            "border:1px solid rgba(255,69,69,.20);"
            "border-radius:14px;}"
        )
        lay = QVBoxLayout(self)
        lay.setContentsMargins(10, 10, 10, 10)
        lay.setSpacing(6)

        self._img_lbl = QLabel()
        self._img_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._img_lbl.setMinimumHeight(160)
        self._img_lbl.setStyleSheet("background:rgba(0,0,0,.30);border-radius:10px;")
        self._img_lbl.setText("Loading image…")
        self._img_lbl.setStyleSheet(
            f"color:{_C.TEXT_DIM};background:rgba(0,0,0,.35);border-radius:10px;"
        )
        lay.addWidget(self._img_lbl)

        if caption:
            cap = QLabel(caption)
            cap.setWordWrap(True)
            cap.setFont(QFont("Segoe UI", 8))
            cap.setStyleSheet(f"color:{_C.TEXT_DIM};")
            lay.addWidget(cap)

        self._load(url)

    def _load(self, url: str):
        try:
            pix = QPixmap()
            if pix.load(url):
                self._set_pixmap(pix)
                return
        except Exception:
            pass
        # Try HTTP via QNetworkAccessManager if available
        try:
            from PyQt6.QtNetwork import QNetworkAccessManager, QNetworkRequest
            self._nam = QNetworkAccessManager(self)
            req = QNetworkRequest(QUrl(url))
            reply = self._nam.get(req)
            reply.finished.connect(lambda r=reply: self._on_reply(r))
        except Exception:
            self._img_lbl.setText("Image unavailable")

    def _on_reply(self, reply):
        try:
            data = reply.readAll()
            pix = QPixmap()
            pix.loadFromData(data)
            self._set_pixmap(pix)
        except Exception:
            self._img_lbl.setText("Image load error")

    def _set_pixmap(self, pix: QPixmap):
        if pix.isNull():
            self._img_lbl.setText("Image unavailable")
            return
        scaled = pix.scaledToWidth(
            min(460, pix.width()),
            Qt.TransformationMode.SmoothTransformation,
        )
        self._img_lbl.setPixmap(scaled)
        self._img_lbl.setFixedHeight(scaled.height() + 8)


class _VideoCard(QFrame):
    """Embedded video preview with a play-link label."""

    def __init__(self, url: str, title: str = "", thumbnail: str = "", parent=None):
        super().__init__(parent)
        self._url = url
        self.setObjectName("VideoCard")
        self.setStyleSheet(
            "QFrame#VideoCard{"
            "background:rgba(10,11,14,230);"
            "border:1px solid rgba(255,69,69,.20);"
            "border-radius:14px;}"
        )
        lay = QVBoxLayout(self)
        lay.setContentsMargins(10, 10, 10, 10)
        lay.setSpacing(8)

        # Thumbnail or placeholder
        self._thumb = QLabel()
        self._thumb.setFixedHeight(140)
        self._thumb.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._thumb.setStyleSheet(
            "background:rgba(0,0,0,.55);border-radius:10px;"
            f"color:{_C.TEXT_DIM};"
        )
        self._thumb.setText("▶")
        self._thumb.setFont(QFont("Segoe UI", 38))
        lay.addWidget(self._thumb)

        if thumbnail:
            self._load_thumb(thumbnail)

        meta = QVBoxLayout()
        meta.setSpacing(3)
        if title:
            t = QLabel(title)
            t.setWordWrap(True)
            t.setFont(QFont("Segoe UI", 9, QFont.Weight.Bold))
            t.setStyleSheet(f"color:{_C.WHITE};")
            meta.addWidget(t)

        link = QLabel(f'<a href="{url}" style="color:#ff7777;">{url[:60]}{"…" if len(url)>60 else ""}</a>')
        link.setOpenExternalLinks(True)
        link.setStyleSheet("background:transparent;")
        meta.addWidget(link)
        lay.addLayout(meta)

    def _load_thumb(self, url: str):
        try:
            from PyQt6.QtNetwork import QNetworkAccessManager, QNetworkRequest
            self._nam = QNetworkAccessManager(self)
            req = QNetworkRequest(QUrl(url))
            reply = self._nam.get(req)
            reply.finished.connect(lambda r=reply: self._on_reply(r))
        except Exception:
            pass

    def _on_reply(self, reply):
        try:
            data = reply.readAll()
            pix = QPixmap()
            pix.loadFromData(data)
            if not pix.isNull():
                scaled = pix.scaledToWidth(460, Qt.TransformationMode.SmoothTransformation)
                self._thumb.setPixmap(scaled)
                self._thumb.setFixedHeight(min(200, scaled.height() + 4))
        except Exception:
            pass


class _SearchResultCard(QFrame):
    """One web-search result row."""

    def __init__(self, title: str, snippet: str, source: str, url: str = "", parent=None):
        super().__init__(parent)
        self.setObjectName("SearchResultCard")
        self.setStyleSheet(
            "QFrame#SearchResultCard{"
            "background:rgba(14,15,19,228);"
            "border:1px solid rgba(255,255,255,.07);"
            "border-radius:12px;}"
            "QFrame#SearchResultCard:hover{"
            "border:1px solid rgba(255,69,69,.28);}"
        )
        lay = QHBoxLayout(self)
        lay.setContentsMargins(12, 10, 12, 10)
        lay.setSpacing(10)

        icon = QLabel("🔍")
        icon.setFixedSize(32, 32)
        icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        icon.setStyleSheet(
            "background:rgba(255,69,69,.08);border:1px solid rgba(255,69,69,.22);"
            "border-radius:16px;font-size:14px;"
        )
        lay.addWidget(icon)

        body = QVBoxLayout()
        body.setContentsMargins(0, 0, 0, 0)
        body.setSpacing(3)

        top = QHBoxLayout()
        top.setSpacing(6)
        t = QLabel(title or "(no title)")
        t.setFont(QFont("Segoe UI", 9, QFont.Weight.Bold))
        t.setStyleSheet(f"color:{_C.WHITE};")
        src = QLabel(source or "")
        src.setFont(QFont("Segoe UI", 7))
        src.setStyleSheet(f"color:{_C.TEXT_DIM};")
        top.addWidget(t)
        top.addStretch()
        top.addWidget(src)
        body.addLayout(top)

        if snippet:
            s = QLabel(snippet[:180] + ("…" if len(snippet) > 180 else ""))
            s.setWordWrap(True)
            s.setFont(QFont("Segoe UI", 8))
            s.setStyleSheet(f"color:{_C.TEXT_MED};")
            body.addWidget(s)

        if url:
            link = QLabel(f'<a href="{url}" style="color:#ff7777;">{url[:55]}{"…" if len(url)>55 else ""}</a>')
            link.setOpenExternalLinks(True)
            link.setFont(QFont("Segoe UI", 7))
            link.setStyleSheet("background:transparent;")
            body.addWidget(link)

        lay.addLayout(body, 1)


class _SearchResultsGroup(QFrame):
    """A collapsible group of search results."""

    def __init__(self, query: str, results: list[dict], parent=None):
        super().__init__(parent)
        self.setObjectName("SearchResultsGroup")
        self.setStyleSheet(
            "QFrame#SearchResultsGroup{"
            "background:rgba(10,11,15,235);"
            "border:1px solid rgba(255,69,69,.18);"
            "border-radius:16px;}"
        )
        lay = QVBoxLayout(self)
        lay.setContentsMargins(12, 12, 12, 12)
        lay.setSpacing(8)

        header = QHBoxLayout()
        icon = QLabel("🔎")
        icon.setFixedSize(24, 24)
        icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        icon.setStyleSheet("font-size:14px;background:transparent;")
        title = QLabel(f'Search results for "<b>{html_lib.escape(query)}</b>"')
        title.setFont(QFont("Segoe UI", 9, QFont.Weight.Bold))
        title.setStyleSheet(f"color:{_C.WHITE};")
        self._toggle = QPushButton("▾")
        self._toggle.setFixedSize(28, 28)
        self._toggle.setFont(QFont("Segoe UI", 10))
        self._toggle.setCursor(Qt.CursorShape.PointingHandCursor)
        self._toggle.setStyleSheet(
            f"QPushButton{{background:rgba(255,255,255,.04);"
            f"color:{_C.WHITE};border:1px solid rgba(255,255,255,.08);"
            f"border-radius:8px;}}"
            f"QPushButton:hover{{border:1px solid {_C.PRI};}}"
        )
        self._toggle.clicked.connect(self._toggle_collapsed)
        header.addWidget(icon)
        header.addWidget(title, 1)
        header.addWidget(self._toggle)
        lay.addLayout(header)

        self._body = QWidget()
        body_lay = QVBoxLayout(self._body)
        body_lay.setContentsMargins(0, 0, 0, 0)
        body_lay.setSpacing(6)
        for r in (results or [])[:6]:
            body_lay.addWidget(
                _SearchResultCard(
                    r.get("title", ""),
                    r.get("snippet", ""),
                    r.get("source", ""),
                    r.get("url", ""),
                )
            )
        lay.addWidget(self._body)
        self._collapsed = False

    def _toggle_collapsed(self):
        self._collapsed = not self._collapsed
        self._body.setVisible(not self._collapsed)
        self._toggle.setText("▸" if self._collapsed else "▾")


# ---------------------------------------------------------------------------
# Audio-mode indicator (shown while recording or when a message came via voice)
# ---------------------------------------------------------------------------
class _AudioWaveformLabel(QWidget):
    """Tiny animated waveform bar shown next to audio messages."""

    def __init__(self, active: bool = False, parent=None):
        super().__init__(parent)
        self._active = active
        self._phase = 0.0
        self.setFixedSize(38, 20)
        if active:
            self._tmr = QTimer(self)
            self._tmr.timeout.connect(self._tick)
            self._tmr.start(40)

    def _tick(self):
        self._phase = (self._phase + 0.18) % (2 * math.pi)
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        W, H = self.width(), self.height()
        bar_w = 3
        gap   = 2
        n     = 7
        total = n * bar_w + (n - 1) * gap
        x0    = (W - total) // 2
        for i in range(n):
            if self._active:
                h = int(4 + 7 * abs(math.sin(self._phase + i * 0.7)))
            else:
                h = 4
            x = x0 + i * (bar_w + gap)
            y = (H - h) // 2
            p.fillRect(x, y, bar_w, h, _qc(_C.PRI, 200 if self._active else 100))
        p.end()


# ---------------------------------------------------------------------------
# Individual chat message bubble
# ---------------------------------------------------------------------------
class ChatMessageBubble(QFrame):
    """
    Unified message bubble for the chat screen.

    role: "user" | "assistant" | "file"
    medium: "text" | "audio"    – how the message was produced
    rich_content: list of dicts, each with a "type" key:
        {"type":"image",  "url":..., "caption":...}
        {"type":"video",  "url":..., "title":..., "thumbnail":...}
        {"type":"search", "query":..., "results":[...]}
    """

    def __init__(
        self,
        role: str,
        name: str,
        text: str,
        stamp: str,
        *,
        medium: str = "text",
        rich_content: list[dict] | None = None,
        animate: bool = False,
        parent=None,
    ):
        super().__init__(parent)
        self._role    = role
        self._medium  = medium
        self._full_text = text or ""
        self._typing_idx = 0
        self._typing_tmr: QTimer | None = None

        self.setObjectName("ChatMessageBubble")
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)

        is_user = role == "user"

        # ── outer layout (message sits left or right) ─────────────────────
        outer = QHBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        # ── bubble frame ──────────────────────────────────────────────────
        bubble = QFrame()
        bubble.setObjectName("BubbleFrame")
        bubble.setSizePolicy(QSizePolicy.Policy.Preferred, QSizePolicy.Policy.Minimum)

        if is_user:
            bubble.setStyleSheet(
                "QFrame#BubbleFrame{"
                "background:qlineargradient(x1:0,y1:0,x2:1,y2:1,"
                "stop:0 rgba(80,20,20,235),stop:1 rgba(40,10,10,228));"
                "border:1px solid rgba(255,69,69,.55);"
                "border-radius:18px 4px 18px 18px;}"
            )
        elif role == "file":
            bubble.setStyleSheet(
                "QFrame#BubbleFrame{"
                "background:rgba(10,20,14,228);"
                "border:1px solid rgba(55,255,95,.30);"
                "border-radius:4px 18px 18px 18px;}"
            )
        else:
            bubble.setStyleSheet(
                "QFrame#BubbleFrame{"
                "background:qlineargradient(x1:0,y1:0,x2:1,y2:1,"
                "stop:0 rgba(16,18,24,242),stop:1 rgba(9,11,16,235));"
                "border:1px solid rgba(255,255,255,.09);"
                "border-left:2px solid rgba(255,69,69,.55);"
                "border-radius:4px 18px 18px 18px;}"
            )

        b_lay = QVBoxLayout(bubble)
        b_lay.setContentsMargins(14, 10, 14, 10)
        b_lay.setSpacing(6)

        # ── header row (avatar + name + time + waveform) ──────────────────
        hdr = QHBoxLayout()
        hdr.setContentsMargins(0, 0, 0, 0)
        hdr.setSpacing(8)

        avatar = QLabel((name or role)[:1].upper())
        avatar.setFixedSize(28, 28)
        avatar.setAlignment(Qt.AlignmentFlag.AlignCenter)
        avatar.setFont(QFont("Segoe UI", 9, QFont.Weight.Bold))
        if is_user:
            avatar.setStyleSheet(
                "background:rgba(255,69,69,.28);"
                "color:#fff;"
                "border:1px solid rgba(255,69,69,.55);"
                "border-radius:14px;"
            )
        elif role == "file":
            avatar.setStyleSheet(
                "background:rgba(55,255,95,.12);"
                "color:#37ff5f;"
                "border:1px solid rgba(55,255,95,.35);"
                "border-radius:14px;"
            )
        else:
            avatar.setStyleSheet(
                "background:rgba(255,69,69,.10);"
                "color:#ff7777;"
                "border:1px solid rgba(255,69,69,.28);"
                "border-radius:14px;"
            )

        name_lbl = QLabel(name or role.capitalize())
        name_lbl.setFont(QFont("Segoe UI", 8, QFont.Weight.Bold))
        name_lbl.setStyleSheet(f"color:{_C.WHITE};background:transparent;")

        if medium == "audio":
            self._wave = _AudioWaveformLabel(active=False)
            hdr.addWidget(avatar)
            hdr.addWidget(name_lbl)
            hdr.addWidget(self._wave)
        else:
            hdr.addWidget(avatar)
            hdr.addWidget(name_lbl)

        if medium == "audio":
            badge = QLabel("🎤")
            badge.setFont(QFont("Segoe UI", 8))
            badge.setStyleSheet(
                f"background:rgba(255,69,69,.12);"
                f"color:{_C.PRI_DIM};"
                f"border:1px solid rgba(255,69,69,.25);"
                f"border-radius:8px;padding:1px 5px;"
            )
            hdr.addWidget(badge)

        hdr.addStretch()

        time_lbl = QLabel(stamp)
        time_lbl.setFont(QFont("Segoe UI", 7))
        time_lbl.setStyleSheet(f"color:rgba(255,255,255,.42);background:transparent;")
        hdr.addWidget(time_lbl)
        b_lay.addLayout(hdr)

        # ── text browser ──────────────────────────────────────────────────
        self._browser = QTextBrowser()
        self._browser.setFrameShape(QFrame.Shape.NoFrame)
        self._browser.setOpenExternalLinks(True)
        self._browser.setReadOnly(True)
        self._browser.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self._browser.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self._browser.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)
        self._browser.setLineWrapMode(QTextEdit.LineWrapMode.WidgetWidth)
        self._browser.setWordWrapMode(QTextOption.WrapMode.WrapAtWordBoundaryOrAnywhere)
        self._browser.setStyleSheet(
            f"QTextBrowser {{"
            f"  background: transparent;"
            f"  border: none;"
            f"  color: {_C.WHITE if not is_user else _C.TEXT};"
            f"  padding: 0;"
            f"}}"
        )
        self._browser.document().setDocumentMargin(0)
        self._render_text(text or "")
        b_lay.addWidget(self._browser, 1)
        

        # ── rich content ──────────────────────────────────────────────────
        for item in (rich_content or []):
            kind = (item.get("type") or "").strip().lower()
            if kind == "image":
                b_lay.addWidget(
                    _ImageCard(item.get("url", ""), item.get("caption", ""))
                )
            elif kind == "video":
                b_lay.addWidget(
                    _VideoCard(
                        item.get("url", ""),
                        item.get("title", ""),
                        item.get("thumbnail", ""),
                    )
                )
            elif kind == "search":
                b_lay.addWidget(
                    _SearchResultsGroup(
                        item.get("query", ""),
                        item.get("results", []),
                    )
                )

        # ── assemble outer layout ─────────────────────────────────────────
        max_frac = 0.76
        bubble.setMaximumWidth(int(900 * max_frac))
        if is_user:
            outer.addStretch(1)
            outer.addWidget(bubble)
            outer.setContentsMargins(80, 4, 10, 4)
        else:
            outer.addWidget(bubble)
            outer.addStretch(1)
            outer.setContentsMargins(10, 4, 80, 4)

        if animate and not is_user:
            self._start_typing()
        else:
            QTimer.singleShot(0, self._fit)

    # ── rendering ─────────────────────────────────────────────────────────
    def _render_text(self, text: str, final: bool = True):
        if final:
            try:
                self._browser.setMarkdown(text or "")
                return
            except Exception:
                pass
        self._browser.setHtml(_md_to_html(text or "", self._role))

    def _start_typing(self):
        self._typing_tmr = QTimer(self)
        self._typing_tmr.setInterval(12)
        self._typing_tmr.timeout.connect(self._tick_typing)
        self._typing_tmr.start()

    def _tick_typing(self):
        self._typing_idx = min(len(self._full_text), self._typing_idx + 4)
        self._render_text(self._full_text[: self._typing_idx], final=False)
        if self._typing_idx >= len(self._full_text):
            self._typing_tmr.stop()
            self._render_text(self._full_text, final=True)
            QTimer.singleShot(0, self._fit)

    def _fit(self):
        try:
            doc = self._browser.document()
            parent = self.parentWidget()
            while parent and not hasattr(parent, "viewport"):
                parent = parent.parentWidget()
            vw = (parent.viewport().width() if parent else 600) or 600
            w = max(220, min(int(vw * 0.72), 640))
            doc.setTextWidth(w)
            doc.adjustSize()
            h = int(doc.size().height()) + 8
            self._browser.setFixedWidth(w)
            self._browser.setMinimumHeight(h)
            self._browser.setMaximumHeight(max(h, 22))
            self.updateGeometry()
        except Exception:
            pass

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._fit()


# ---------------------------------------------------------------------------
# Recording-in-progress indicator
# ---------------------------------------------------------------------------
class _RecordingIndicator(QFrame):
    """Pulsing red bar shown while the mic is active."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("RecordingIndicator")
        self.setFixedHeight(44)
        self.setStyleSheet(
            "QFrame#RecordingIndicator{"
            "background:rgba(40,8,8,235);"
            "border:1px solid rgba(255,69,69,.55);"
            "border-radius:22px;}"
        )
        lay = QHBoxLayout(self)
        lay.setContentsMargins(16, 0, 16, 0)
        lay.setSpacing(12)

        self._wave = _AudioWaveformLabel(active=True)
        lay.addWidget(self._wave)

        self._lbl = QLabel("Listening…")
        self._lbl.setFont(QFont("Segoe UI", 10, QFont.Weight.Bold))
        self._lbl.setStyleSheet(f"color:{_C.WHITE};background:transparent;")
        lay.addWidget(self._lbl, 1)

        self._stop = QPushButton("■  Stop")
        self._stop.setFixedHeight(30)
        self._stop.setFont(QFont("Segoe UI", 9, QFont.Weight.Bold))
        self._stop.setCursor(Qt.CursorShape.PointingHandCursor)
        self._stop.setStyleSheet(
            f"QPushButton{{background:rgba(255,69,69,.18);color:{_C.WHITE};"
            f"border:1px solid rgba(255,69,69,.55);border-radius:15px;padding:0 12px;}}"
            f"QPushButton:hover{{background:rgba(255,69,69,.32);}}"
        )
        lay.addWidget(self._stop)

        self._dot = True
        self._tmr = QTimer(self)
        self._tmr.timeout.connect(self._blink)
        self._tmr.start(600)

    def _blink(self):
        self._dot = not self._dot
        prefix = "🔴" if self._dot else "⭕"
        self._lbl.setText(f"{prefix}  Listening…")

    def set_transcribing(self):
        self._tmr.stop()
        self._lbl.setText("Transcribing…")
        self._wave._active = False


# ---------------------------------------------------------------------------
# Chat input bar  (text field  +  mic  +  attach  +  send)
# ---------------------------------------------------------------------------
class ChatInputBar(QFrame):
    """
    Full-featured input bar for the chat screen.
    Signals
    -------
    submitted(text: str)
    mic_pressed()
    mic_released()
    attach_clicked()
    """

    submitted     = pyqtSignal(str)
    mic_pressed   = pyqtSignal()
    mic_released  = pyqtSignal()
    attach_clicked = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("ChatInputBar")
        self.setFixedHeight(72)
        self.setStyleSheet(
            "QFrame#ChatInputBar{"
            "background:qlineargradient(x1:0,y1:0,x2:1,y2:0,"
            "stop:0 rgba(10,11,14,250),stop:.5 rgba(16,17,21,248),"
            "stop:1 rgba(10,11,14,250));"
            "border:1px solid rgba(255,255,255,.09);"
            "border-radius:24px;}"
        )
        lay = QHBoxLayout(self)
        lay.setContentsMargins(16, 14, 16, 14)
        lay.setSpacing(10)

        self._input = QLineEdit()
        self._input.setPlaceholderText("Message Brahma…")
        self._input.setFont(QFont("Segoe UI", 11))
        self._input.setFixedHeight(44)
        self._input.setStyleSheet(
            f"QLineEdit{{background:rgba(255,255,255,.03);"
            f"color:{_C.WHITE};"
            f"border:1px solid rgba(255,255,255,.07);"
            f"border-radius:999px;padding:0 16px;"
            f"selection-background-color:rgba(255,255,255,.15);}}"
            f"QLineEdit:focus{{border:1px solid rgba(255,69,69,.38);}}"
        )
        self._input.returnPressed.connect(self._send)
        lay.addWidget(self._input, 1)

        _s = (
            "QPushButton{{background:rgba(14,15,19,245);color:{c};"
            "border:1px solid {b};border-radius:7px;}}"
            "QPushButton:hover{{background:rgba(255,69,69,.14);"
            "color:{p};border:1px solid {p};}}"
            "QPushButton:pressed{{background:rgba(255,69,69,.28);}}"
        )

        def _icon_btn(tooltip: str) -> QPushButton:
            btn = QPushButton()
            btn.setFixedSize(44, 44)
            btn.setToolTip(tooltip)
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn.setStyleSheet(
                _s.format(c=_C.WHITE, b=_C.BORDER_B, p=_C.PRI)
            )
            return btn

        # Attach
        self._attach_btn = _icon_btn("Attach file")
        self._attach_btn.setText("⎙")
        self._attach_btn.setFont(QFont("Segoe UI", 14))
        self._attach_btn.clicked.connect(self.attach_clicked.emit)
        lay.addWidget(self._attach_btn)

        # Mic  (hold-to-talk OR click-to-toggle)
        self._mic_btn = QPushButton()
        self._mic_btn.setFixedSize(44, 44)
        self._mic_btn.setText("🎤")
        self._mic_btn.setFont(QFont("Segoe UI", 14))
        self._mic_btn.setToolTip("Hold to talk  /  Click to toggle voice input")
        self._mic_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self._mic_btn.setCheckable(True)
        self._mic_btn.setStyleSheet(
            f"QPushButton{{background:rgba(20,10,10,245);color:{_C.PRI};"
            f"border:1px solid {_C.PRI};border-radius:7px;}}"
            f"QPushButton:checked{{background:rgba(255,69,69,.22);"
            f"border:1px solid {_C.PRI_DIM};}}"
            f"QPushButton:hover{{background:rgba(255,69,69,.28);}}"
        )
        self._mic_btn.clicked.connect(self._on_mic_clicked)
        lay.addWidget(self._mic_btn)

        # Send
        self._send_btn = _icon_btn("Send  [Enter]")
        self._send_btn.setText("➤")
        self._send_btn.setFont(QFont("Segoe UI", 13, QFont.Weight.Bold))
        self._send_btn.setStyleSheet(
            f"QPushButton{{background:rgba(255,69,69,.16);color:{_C.WHITE};"
            f"border:1px solid rgba(255,69,69,.55);border-radius:7px;}}"
            f"QPushButton:hover{{background:rgba(255,69,69,.30);}}"
            f"QPushButton:pressed{{background:rgba(255,69,69,.46);}}"
        )
        self._send_btn.clicked.connect(self._send)
        lay.addWidget(self._send_btn)

        self._recording = False

    # ── public API ────────────────────────────────────────────────────────
    def set_recording(self, active: bool):
        self._recording = bool(active)
        self._mic_btn.setChecked(active)
        self._input.setEnabled(not active)
        placeholder = "Listening…  (click mic to stop)" if active else "Message Brahma…"
        self._input.setPlaceholderText(placeholder)

    def clear(self):
        self._input.clear()

    def focus(self):
        self._input.setFocus()

    # ── slots ─────────────────────────────────────────────────────────────
    def _send(self):
        txt = self._input.text().strip()
        if not txt:
            return
        self._input.clear()
        self.submitted.emit(txt)

    def _on_mic_clicked(self, checked: bool):
        if checked:
            self.mic_pressed.emit()
        else:
            self.mic_released.emit()
        self.set_recording(checked)


# ---------------------------------------------------------------------------
# Scrollable message feed (chat-only, no event cards)
# ---------------------------------------------------------------------------
class ChatFeed(QScrollArea):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWidgetResizable(True)
        self.setFrameShape(QFrame.Shape.NoFrame)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setStyleSheet(
            "QScrollArea{background:transparent;border:none;}"
            "QScrollBar:vertical{background:transparent;width:7px;border:none;margin:6px 0;}"
            "QScrollBar::handle:vertical{background:rgba(255,69,69,.35);border-radius:3px;min-height:24px;}"
            "QScrollBar::handle:vertical:hover{background:rgba(255,69,69,.55);}"
        )
        self._content = QWidget()
        self._content.setStyleSheet("background:transparent;")
        self._lay = QVBoxLayout(self._content)
        self._lay.setContentsMargins(10, 10, 10, 10)
        self._lay.setSpacing(10)
        self._lay.addStretch(1)
        self.setWidget(self._content)
        self._count = 0

    def add_bubble(
        self,
        role: str,
        name: str,
        text: str,
        stamp: str = "",
        *,
        medium: str = "text",
        rich_content: list[dict] | None = None,
        animate: bool = False,
    ):
        if self._lay.count() and self._lay.itemAt(self._lay.count() - 1).spacerItem():
            self._lay.takeAt(self._lay.count() - 1)
        bubble = ChatMessageBubble(
            role, name, text, stamp or _fmt_stamp(),
            medium=medium,
            rich_content=rich_content,
            animate=animate,
            parent=self,
        )
        self._lay.addWidget(bubble)
        self._lay.addStretch(1)
        self._count += 1
        QTimer.singleShot(0, self._scroll_bottom)

    def clear(self):
        while self._lay.count():
            item = self._lay.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        self._lay.addStretch(1)
        self._count = 0

    def load_history(self, messages: list[dict]):
        self.clear()
        for msg in messages:
            role = (msg.get("role") or "assistant").lower()
            if role == "system":
                continue                    # event cards stay in dashboard
            name = {"user": "You", "assistant": "Brahma", "file": "Files"}.get(role, "Brahma")
            self.add_bubble(
                role, name,
                msg.get("content") or "",
                _fmt_stamp(msg.get("timestamp")),
                medium=msg.get("medium", "text"),
                rich_content=msg.get("rich_content"),
                animate=False,
            )

    def _scroll_bottom(self):
        bar = self.verticalScrollBar()
        bar.setValue(bar.maximum())

    def resizeEvent(self, event):
        super().resizeEvent(event)
        for i in range(self._lay.count()):
            w = self._lay.itemAt(i).widget()
            if hasattr(w, "_fit"):
                w._fit()
        QTimer.singleShot(0, self._scroll_bottom)


# ---------------------------------------------------------------------------
# Day-separator label
# ---------------------------------------------------------------------------
class _DateSeparator(QWidget):
    def __init__(self, label: str, parent=None):
        super().__init__(parent)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 6, 0, 6)
        lay.setSpacing(8)
        for _ in range(2):
            line = QFrame()
            line.setFrameShape(QFrame.Shape.HLine)
            line.setStyleSheet(f"color:rgba(255,255,255,.10);")
            lay.addWidget(line, 1)
        lbl = QLabel(label)
        lbl.setFont(QFont("Segoe UI", 8))
        lbl.setStyleSheet(
            f"color:{_C.TEXT_DIM};"
            f"background:rgba(10,11,14,210);"
            f"border:1px solid rgba(255,255,255,.07);"
            f"border-radius:10px;padding:2px 10px;"
        )
        lay.insertWidget(1, lbl)


# ---------------------------------------------------------------------------
# The main ChatPage widget
# ---------------------------------------------------------------------------
class ChatPage(QWidget):
    """
    Full-screen chat panel.  Replace (or stack alongside) the dashboard.

    Public API
    ----------
    push_message(role, text, *, medium, rich_content, animate)
        Call from the UI thread (or via a QTimer.singleShot wrapper).
    set_recording(active)
        Drive the recording indicator from the STT controller.
    load_conversation(messages)
        Restore a conversation list (same format as workspace_store).

    Signals
    -------
    command_submitted(str)   – user hit send with text
    mic_pressed()            – mic button toggled ON
    mic_released()           – mic button toggled OFF
    attach_clicked()         – attach button pressed
    """

    command_submitted = pyqtSignal(str)
    mic_pressed       = pyqtSignal()
    mic_released      = pyqtSignal()
    attach_clicked    = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("ChatPage")
        self.setStyleSheet("QWidget#ChatPage{background:transparent;}")

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # ── header ────────────────────────────────────────────────────────
        header = self._build_header()
        root.addWidget(header)

        # ── feed + recording indicator stack ──────────────────────────────
        self._feed = ChatFeed()
        root.addWidget(self._feed, 1)

        self._rec_indicator = _RecordingIndicator()
        self._rec_indicator.hide()
        self._rec_indicator._stop.clicked.connect(self._stop_recording)
        root.addWidget(self._rec_indicator)

        # ── empty-state hint (shown when no messages) ─────────────────────
        self._empty = self._build_empty_state()
        self._feed.setViewportMargins(0, 0, 0, 0)

        # ── input bar ─────────────────────────────────────────────────────
        bar_wrap = QWidget()
        bar_wrap.setStyleSheet("background:transparent;")
        bar_lay = QHBoxLayout(bar_wrap)
        bar_lay.setContentsMargins(12, 8, 12, 14)
        bar_lay.setSpacing(0)
        self._input_bar = ChatInputBar()
        self._input_bar.submitted.connect(self._on_text_submitted)
        self._input_bar.mic_pressed.connect(self._start_recording)
        self._input_bar.mic_released.connect(self._stop_recording)
        self._input_bar.attach_clicked.connect(self.attach_clicked.emit)
        bar_lay.addWidget(self._input_bar)
        root.addWidget(bar_wrap)

        self._recording = False
        self._update_empty_state()

    # ── header ────────────────────────────────────────────────────────────
    def _build_header(self) -> QWidget:
        w = QWidget()
        w.setFixedHeight(58)
        w.setStyleSheet(
            "QWidget{"
            "background:rgba(8,9,13,235);"
            "border-bottom:1px solid rgba(255,255,255,.07);}"
        )
        lay = QHBoxLayout(w)
        lay.setContentsMargins(18, 0, 18, 0)
        lay.setSpacing(12)

        # Left – avatar + title
        avatar = QLabel("B")
        avatar.setFixedSize(36, 36)
        avatar.setAlignment(Qt.AlignmentFlag.AlignCenter)
        avatar.setFont(QFont("Segoe UI", 13, QFont.Weight.Bold))
        avatar.setStyleSheet(
            "background:rgba(255,69,69,.15);"
            "color:#ff7777;"
            "border:1px solid rgba(255,69,69,.45);"
            "border-radius:18px;"
        )
        lay.addWidget(avatar)

        title_col = QVBoxLayout()
        title_col.setSpacing(1)
        title = QLabel("Brahma AI")
        title.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
        title.setStyleSheet(f"color:{_C.WHITE};background:transparent;")
        self._header_status = QLabel("● Online  ·  Gemini 2.5 Flash")
        self._header_status.setFont(QFont("Segoe UI", 8))
        self._header_status.setStyleSheet(f"color:{_C.GREEN};background:transparent;")
        title_col.addWidget(title)
        title_col.addWidget(self._header_status)
        lay.addLayout(title_col)
        lay.addStretch()

        # Right – mode chip + clear button
        self._mode_chip = QLabel("TEXT  +  VOICE")
        self._mode_chip.setFont(QFont("Segoe UI", 8, QFont.Weight.Bold))
        self._mode_chip.setStyleSheet(
            f"color:{_C.TEXT_MED};"
            f"background:rgba(255,255,255,.04);"
            f"border:1px solid rgba(255,255,255,.08);"
            f"border-radius:10px;padding:4px 10px;"
        )
        lay.addWidget(self._mode_chip)

        clear_btn = QPushButton("Clear")
        clear_btn.setFixedHeight(30)
        clear_btn.setFont(QFont("Segoe UI", 8, QFont.Weight.Bold))
        clear_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        clear_btn.setStyleSheet(
            f"QPushButton{{background:rgba(255,255,255,.03);color:{_C.TEXT_MED};"
            f"border:1px solid rgba(255,255,255,.07);border-radius:10px;padding:0 12px;}}"
            f"QPushButton:hover{{border:1px solid {_C.PRI};color:{_C.WHITE};}}"
        )
        clear_btn.clicked.connect(self._feed.clear)
        clear_btn.clicked.connect(self._update_empty_state)
        lay.addWidget(clear_btn)
        return w

    # ── empty state ───────────────────────────────────────────────────────
    def _build_empty_state(self) -> QWidget:
        w = QWidget()
        w.setStyleSheet("background:transparent;")
        lay = QVBoxLayout(w)
        lay.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.setSpacing(12)

        icon = QLabel("💬")
        icon.setFont(QFont("Segoe UI", 46))
        icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        icon.setStyleSheet("background:transparent;")
        lay.addWidget(icon)

        title = QLabel("Start a conversation")
        title.setFont(QFont("Segoe UI", 16, QFont.Weight.Bold))
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet(f"color:{_C.WHITE};background:transparent;")
        lay.addWidget(title)

        sub = QLabel("Type a message or press the mic to speak.\nBrahma can also show images, videos and search results inline.")
        sub.setWordWrap(True)
        sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
        sub.setFont(QFont("Segoe UI", 10))
        sub.setStyleSheet(f"color:{_C.TEXT_DIM};background:transparent;")
        lay.addWidget(sub)

        # Quick-start chips
        chips_row = QHBoxLayout()
        chips_row.setAlignment(Qt.AlignmentFlag.AlignCenter)
        chips_row.setSpacing(8)
        for suggestion in ["Search the web", "Explain something", "Analyze a file", "Tell me a joke"]:
            chip = QPushButton(suggestion)
            chip.setCursor(Qt.CursorShape.PointingHandCursor)
            chip.setFont(QFont("Segoe UI", 9))
            chip.setStyleSheet(
                f"QPushButton{{background:rgba(255,255,255,.04);color:{_C.TEXT_MED};"
                f"border:1px solid rgba(255,255,255,.08);border-radius:16px;padding:6px 14px;}}"
                f"QPushButton:hover{{background:rgba(255,69,69,.10);color:{_C.WHITE};"
                f"border:1px solid rgba(255,69,69,.35);}}"
            )
            chip.clicked.connect(lambda _, s=suggestion: self._quick_start(s))
            chips_row.addWidget(chip)
        lay.addLayout(chips_row)

        return w

    def _quick_start(self, text: str):
        self._input_bar._input.setText(text)
        self._input_bar.focus()

    def _update_empty_state(self):
        show = self._feed._count == 0
        # overlay the empty widget over the feed
        if show:
            if self._empty.parent() is not self:
                self._empty.setParent(self)
            self._empty.setGeometry(
                0, 58,
                self.width(),
                self.height() - 58 - self._input_bar.height() - 22,
            )
            self._empty.show()
            self._empty.raise_()
        else:
            self._empty.hide()

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._update_empty_state()

    # ── recording flow ────────────────────────────────────────────────────
    def _start_recording(self):
        self._recording = True
        self._rec_indicator.show()
        self._input_bar.set_recording(True)
        self.mic_pressed.emit()
        self._header_status.setText("🔴 Recording…")
        self._header_status.setStyleSheet(f"color:{_C.PRI};background:transparent;")

    def _stop_recording(self):
        self._recording = False
        self._rec_indicator.hide()
        self._input_bar.set_recording(False)
        self.mic_released.emit()
        self._header_status.setText("● Online  ·  Gemini 2.5 Flash")
        self._header_status.setStyleSheet(f"color:{_C.GREEN};background:transparent;")

    def set_recording(self, active: bool):
        if active and not self._recording:
            self._start_recording()
        elif not active and self._recording:
            self._stop_recording()

    # ── text submit ───────────────────────────────────────────────────────
    def _on_text_submitted(self, text: str):
        self.push_message("user", text, medium="text", animate=False)
        self.command_submitted.emit(text)
        self._update_empty_state()

    # ── public push API ───────────────────────────────────────────────────
    def push_message(
        self,
        role: str,
        text: str,
        *,
        medium: str = "text",
        rich_content: list[dict] | None = None,
        animate: bool = True,
        timestamp=None,
    ):
        """
        Inject a message into the feed from anywhere (call on the main thread).
        role: "user" | "assistant" | "file"
        medium: "text" | "audio"
        """
        role = (role or "assistant").strip().lower()
        if role == "system":
            return  # system / event cards go to the dashboard only
        name = {"user": "You", "assistant": "Brahma", "file": "Files"}.get(role, "Brahma")
        stamp = _fmt_stamp(timestamp)
        do_anim = animate and role == "assistant"
        self._feed.add_bubble(
            role, name, text, stamp,
            medium=medium,
            rich_content=rich_content,
            animate=do_anim,
        )
        if role == "assistant":
            self._update_header_state("online")
        self._update_empty_state()

    def push_audio_message(self, role: str, transcription: str, timestamp=None):
        """Convenience wrapper for voice-produced messages."""
        self.push_message(role, transcription, medium="audio", timestamp=timestamp)

    def push_search_results(self, query: str, results: list[dict], ai_text: str = ""):
        """Attach search results to an AI message."""
        rich = [{"type": "search", "query": query, "results": results}]
        self.push_message("assistant", ai_text or f"Here are search results for **{query}**:", rich_content=rich)

    def push_image(self, url: str, caption: str = "", ai_text: str = ""):
        rich = [{"type": "image", "url": url, "caption": caption}]
        self.push_message("assistant", ai_text, rich_content=rich)

    def push_video(self, url: str, title: str = "", thumbnail: str = "", ai_text: str = ""):
        rich = [{"type": "video", "url": url, "title": title, "thumbnail": thumbnail}]
        self.push_message("assistant", ai_text, rich_content=rich)

    def load_conversation(self, messages: list[dict]):
        self._feed.load_history(messages)
        self._update_empty_state()

    def clear(self):
        self._feed.clear()
        self._update_empty_state()

    def _update_header_state(self, state: str):
        if state == "thinking":
            self._header_status.setText("● Thinking…")
            self._header_status.setStyleSheet(f"color:#ffb347;background:transparent;")
        elif state == "recording":
            self._header_status.setText("🔴 Recording…")
            self._header_status.setStyleSheet(f"color:{_C.PRI};background:transparent;")
        else:
            self._header_status.setText("● Online  ·  Gemini 2.5 Flash")
            self._header_status.setStyleSheet(f"color:{_C.GREEN};background:transparent;")

    def set_ai_state(self, state: str):
        """Called by the backend to reflect AI state in the header."""
        self._update_header_state(state)


# ---------------------------------------------------------------------------
# Integration patch for MainWindow
# ---------------------------------------------------------------------------
# The snippet below shows exactly what to change in MainWindow.
# Do NOT paste it verbatim – apply each diff to your existing code.

_INTEGRATION_NOTES = """
# ── HOW TO WIRE ChatPage INTO YOUR MainWindow ──────────────────────────────
#
# 1.  Import at top of ui.py
#     from chat_page import ChatPage, ChatInputBar
#
# 2.  In _build_center_panel_modern():
#
#     a) Remove self._command_panel and self._build_command_row() from the
#        dashboard stage layout (delete those 5–6 lines).
#
#     b) Build the ChatPage and add it to the stack:
#
#         self._chat_page = ChatPage()
#         self._chat_page.command_submitted.connect(self.submit_command)
#         self._chat_page.mic_pressed.connect(self._toggle_mute)
#         self._chat_page.mic_released.connect(self._toggle_mute)
#         self._chat_page.attach_clicked.connect(self._browse_attachment)
#
#         self._center_stack = QStackedWidget()
#         self._center_stack.addWidget(w)               # index 0  dashboard
#         self._center_stack.addWidget(self._home_page) # index 1  home
#         self._center_stack.addWidget(self._settings_page)  # index 2
#         self._center_stack.addWidget(self._chat_page) # index 3  ← new
#         self._center_stack.setCurrentIndex(0)
#         return self._center_stack
#
# 3.  Add "Chat" to the left nav in _build_left_panel_modern():
#
#         self._nav_items["chat"] = NavItem("Chat", active=False, letter="✉")
#         self._nav_items["chat"].clicked.connect(lambda: activate("chat"))
#         lay.addWidget(self._nav_items["chat"])   # after "home"
#
# 4.  Update _set_page() to handle index 3:
#
#         index = {"dashboard": 0, "home": 1, "settings": 2, "chat": 3}.get(page, 0)
#         self._center_stack.setCurrentIndex(index)
#
# 5.  In _on_log_text() forward AI replies to the chat page:
#
#         if low.startswith("brahma ai:") or low.startswith("brahma:"):
#             reply = raw.split(":", 1)[1].strip()
#             # existing result_card logic …
#             self._chat_page.push_message("assistant", reply, medium="text", animate=True)
#
#     And for user messages:
#         if low.startswith("you:"):
#             user_msg = raw.split(":", 1)[1].strip()
#             self._chat_page.push_message("user", user_msg, medium="text", animate=False)
#
# 6.  In BrahmaUI, after self._win._state_sig.connect(…) add:
#
#         self._win._state_sig.connect(
#             lambda s: self._win._chat_page.set_ai_state(
#                 "thinking" if s == "THINKING" else
#                 "recording" if s in ("LISTENING","MUTED") else "online"
#             )
#         )
#
# 7.  Rich-content helpers (call from your backend thread via QTimer.singleShot):
#
#         QTimer.singleShot(0, lambda: self._win._chat_page.push_search_results(
#             query="latest AI news",
#             results=[{"title":…,"snippet":…,"url":…,"source":…}, …],
#             ai_text="Here is what I found:",
#         ))
#         QTimer.singleShot(0, lambda: self._win._chat_page.push_image(
#             url="https://example.com/img.jpg", caption="Requested image"
#         ))
#         QTimer.singleShot(0, lambda: self._win._chat_page.push_video(
#             url="https://youtu.be/xyz", title="Demo video"
#         ))
# ────────────────────────────────────────────────────────────────────────────
"""
