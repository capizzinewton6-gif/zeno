"""
dashboard/api_server.py — Enhanced Brahma AI Dashboard API Server

This server extends the basic dashboard server to expose ALL desktop features
via REST API endpoints, making them available to the web interface.

Features exposed:
- File processing (images, PDFs, documents, code, audio, video, etc.)
- Web search (Gemini-powered and DuckDuckGo)
- Computer control (keyboard, mouse, clipboard, screenshots)
- YouTube operations (search, play, summarize, info)
- Smart home control
- Office tools (Word, Excel, PowerPoint, PDF)
- Code helper
- Dev agent
- Meeting assistant
- And more...

Install deps: pip install fastapi "uvicorn[standard]" cryptography python-multipart
"""

import asyncio
import base64
import hashlib
import json
import re
import secrets
import socket
import string
import time
from pathlib import Path
from typing import Any

_DEPS_OK = False
try:
    from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Request, HTTPException
    from fastapi.responses import HTMLResponse, JSONResponse, FileResponse
    from fastapi.staticfiles import StaticFiles
    import uvicorn
    _DEPS_OK = True
except ImportError:
    pass

_UPLOAD_OK = False
try:
    from fastapi import UploadFile, File as FastAPIFile
    _UPLOAD_OK = True
except Exception:
    pass

BASE_DIR = Path(__file__).resolve().parent.parent
STATIC_DIR = Path(__file__).parent / "static"
PORT = 8000
MAX_UPLOAD_MB = 500


def _make_uploads_dir() -> Path:
    """Return (and create) the cross-platform uploads folder."""
    for candidate in [
        Path.home() / "Downloads" / "Brahma Uploads",
        Path.home() / "Documents" / "Brahma Uploads",
        BASE_DIR / "uploads",
    ]:
        try:
            candidate.mkdir(parents=True, exist_ok=True)
            return candidate
        except Exception:
            pass
    return BASE_DIR / "uploads"


UPLOADS_DIR = _make_uploads_dir()


_KEY_CHARS = [c for c in (string.ascii_uppercase + string.digits)
              if c not in ('O', 'I', 'L', '0', '1')]

_AES_SALT = b'BRAHMA-DASHBOARD-v1'


def _derive_key(session_key: str) -> bytes:
    """SHA-256(sessionKey||salt) -> 32-byte AES-256 key."""
    return hashlib.sha256(session_key.encode('utf-8') + _AES_SALT).digest()


def _decrypt_cbc(aes_key: bytes, enc_b64: str) -> str:
    """Decrypt base64(IV[16] || ciphertext) with AES-256-CBC + PKCS7."""
    from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
    from cryptography.hazmat.primitives import padding as sym_pad
    raw = base64.b64decode(enc_b64)
    iv, ct = raw[:16], raw[16:]
    dec = Cipher(algorithms.AES(aes_key), modes.CBC(iv)).decryptor()
    padded = dec.update(ct) + dec.finalize()
    unpadder = sym_pad.PKCS7(128).unpadder()
    return (unpadder.update(padded) + unpadder.finalize()).decode('utf-8')


CRYPTOJS_CDN = ("https://cdnjs.cloudflare.com/ajax/libs/"
                "crypto-js/4.2.0/crypto-js.min.js")
CRYPTOJS_FILE = STATIC_DIR / "crypto-js.min.js"


def _ensure_crypto_js() -> None:
    if CRYPTOJS_FILE.exists():
        return
    try:
        import urllib.request
        print("[Dashboard] Downloading CryptoJS (one-time setup)...")
        urllib.request.urlretrieve(CRYPTOJS_CDN, str(CRYPTOJS_FILE))
        print("[Dashboard] CryptoJS cached — will serve locally from now on.")
    except Exception as e:
        print(f"[Dashboard] CryptoJS download failed: {e}")


_ensure_crypto_js()


# Import all action modules
_simple_actions = {
    "file_processor": "file_processor",
    "web_search": "web_search",
    "computer_control": "computer_control",
    "youtube_video": "youtube_video",
    "open_app": "open_app",
    "weather_report": "weather_action",
    "send_message": "send_message",
    "reminder": "reminder",
    "screen_processor": "screen_process",
    "meeting_assistant": "MeetingAssistant",
    "browser_control": "browser_control",
    "file_controller": "file_controller",
    "code_helper": "code_helper",
    "dev_agent": "dev_agent",
    "office_builder": "office_builder",
    "docx_tools": "word_document",
    "pdf_tools": "create_pdf",
    "website_builder": "website_builder",
    "computer_settings": "computer_settings",
    "desktop": "desktop_control",
    "game_updater": "game_updater",
    "flight_finder": "flight_finder",
}


class EnhancedDashboardServer:
    """
    Enhanced dashboard server with full desktop feature access via API.
    """

    def __init__(self):
        self._ip = "127.0.0.1"  # Will be set properly
        self._tokens: set[str] = set()
        self._token_keys: dict[str, str] = {}
        self._aes_cache: dict[str, bytes] = {}
        self._clients: set[WebSocket] = set()
        self._history: list[dict] = []
        self._command_queue = asyncio.Queue()
        self._wake_callback = None
        self._connect_callback = None
        self._pending_keys: dict[str, float] = {}
        self._device_sessions: dict[str, dict] = {}
        self._phone_audio_queue: asyncio.Queue = asyncio.Queue(maxsize=200)
        self._uploads_dir = UPLOADS_DIR
        self._login_html = self._read("login.html")
        self._app_html = self._read("app.html")
        self._brahma_web_html = self._read("brahma_web.html")
        self.app = self._build_app()

        # Load action modules dynamically
        self._action_modules = {}
        self._load_action_modules()

    def _read(self, name: str) -> str:
        path = STATIC_DIR / name
        if path.exists():
            return path.read_text(encoding="utf-8")
        return f"<html><body>File {name} not found</body></html>"

    def _load_action_modules(self):
        """Load all action modules dynamically."""
        import sys
        import importlib
        
        actions_dir = BASE_DIR / "actions"
        if not actions_dir.exists():
            print(f"[Dashboard] Actions directory not found: {actions_dir}")
            return

        for module_name, function_name in _simple_actions.items():
            try:
                module = importlib.import_module(f"actions.{module_name}")
                func = getattr(module, function_name, None)
                if func:
                    self._action_modules[module_name] = func
                    print(f"[Dashboard] Loaded action module: {module_name}")
            except Exception as e:
                print(f"[Dashboard] Failed to load {module_name}: {e}")

    def new_key(self, expiry_secs: int = 600) -> str:
        now = time.time()
        self._pending_keys = {k: v for k, v in self._pending_keys.items() if v > now}
        key = ''.join(secrets.choice(_KEY_CHARS) for _ in range(6))
        self._pending_keys[key] = now + expiry_secs
        return key

    def get_url(self) -> str:
        return f"http://{self._ip}:{PORT}"

    def get_manual_url(self) -> str:
        return f"http://{self._ip}:{PORT}"

    def _aes_key(self, session_key: str) -> bytes:
        if session_key not in self._aes_cache:
            self._aes_cache[session_key] = _derive_key(session_key)
        return self._aes_cache[session_key]

    def _decrypt(self, token: str, enc_b64: str) -> str | None:
        sk = self._token_keys.get(token)
        if not sk:
            return None
        try:
            return _decrypt_cbc(self._aes_key(sk), enc_b64)
        except Exception:
            return None

    def set_wake_callback(self, fn) -> None:
        self._wake_callback = fn

    def set_connect_callback(self, fn) -> None:
        self._connect_callback = fn

    async def broadcast(self, msg: dict) -> None:
        self._history.append(msg)
        if len(self._history) > 300:
            self._history = self._history[-300:]
        dead: set[WebSocket] = set()
        for ws in list(self._clients):
            try:
                await ws.send_json(msg)
            except Exception:
                dead.add(ws)
        self._clients -= dead

    def _build_app(self) -> FastAPI:
        app = FastAPI(docs_url="/api/docs", redoc_url=None)

        def _auth(req: Request) -> bool:
            tok = req.headers.get("authorization", "").removeprefix("Bearer ").strip()
            return bool(tok) and tok in self._tokens

        # Serve static files
        app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

        # Serve CryptoJS
        @app.get("/static/crypto.js")
        async def serve_crypto():
            if CRYPTOJS_FILE.exists():
                return FileResponse(str(CRYPTOJS_FILE), media_type="application/javascript")
            from fastapi.responses import RedirectResponse
            return RedirectResponse(CRYPTOJS_CDN)

        # Login page
        @app.get("/login", response_class=HTMLResponse)
        async def login_page():
            return HTMLResponse(self._login_html)

        # Main app pages
        @app.get("/", response_class=HTMLResponse)
        async def index():
            html = (self._app_html
                    .replace("__IP__", self._ip)
                    .replace("__PORT__", str(PORT)))
            return HTMLResponse(html)

        @app.get("/brahma", response_class=HTMLResponse)
        async def brahma_web():
            html = (self._brahma_web_html
                    .replace("__IP__", self._ip)
                    .replace("__PORT__", str(PORT)))
            return HTMLResponse(html)

        # Login endpoint
        @app.post("/login")
        async def login(req: Request):
            body = await req.json()
            entered = str(body.get("pin", "")).strip().upper()
            now = time.time()
            if entered in self._pending_keys and self._pending_keys[entered] > now:
                del self._pending_keys[entered]
                tok = secrets.token_urlsafe(32)
                self._tokens.add(tok)
                self._token_keys[tok] = entered
                self._aes_key(entered)
                if self._connect_callback:
                    self._connect_callback()
                asyncio.create_task(self.broadcast(
                    {"type": "sys", "text": "Remote connection established."}
                ))
                return JSONResponse({"ok": True, "token": tok})
            return JSONResponse({"ok": False, "error": "Invalid or expired key"}, status_code=401)

        # Auto-login for QR code
        @app.get("/auto-login")
        async def auto_login(key: str = ""):
            now = time.time()
            if not key or key not in self._pending_keys or self._pending_keys[key] <= now:
                return HTMLResponse("""<!DOCTYPE html>
<html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width">
<style>body{background:#07090f;color:#dde3ed;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;text-align:center}
h2{color:#f87171;margin-bottom:12px}p{color:#5e6a7e;font-size:14px}</style></head>
<body><div><h2>Link Expired</h2>
<p>Press Mobile Connect in Brahma to get a new QR code.</p></div></body></html>""")

            del self._pending_keys[key]
            tok = secrets.token_urlsafe(32)
            dev_tok = secrets.token_urlsafe(32)
            self._tokens.add(tok)
            self._token_keys[tok] = key
            self._aes_key(key)
            self._device_sessions[dev_tok] = {"session_key": key}

            if self._connect_callback:
                self._connect_callback()
            asyncio.create_task(self.broadcast(
                {"type": "sys", "text": "Remote connection established via QR code."}
            ))

            return HTMLResponse(f"""<!DOCTYPE html>
<html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width">
<style>body{{background:#07090f;color:#dde3ed;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;text-align:center}}
p{{color:#5e6a7e;font-size:14px}}</style></head>
<body>
<script>
sessionStorage.setItem('jarvis_token','{tok}');
sessionStorage.setItem('jarvis_key','{key}');
localStorage.setItem('jarvis_device_token','{dev_tok}');
setTimeout(function(){{location.replace('/brahma')}},400);
</script>
<p>Connecting to Brahma...</p>
</body></html>""")

        # Device login
        @app.post("/api/device-login")
        async def device_login_ep(req: Request):
            try:
                body = await req.json()
            except Exception:
                return JSONResponse({"ok": False}, status_code=400)
            dev_tok = (body.get("device_token") or "").strip()
            if not dev_tok or dev_tok not in self._device_sessions:
                return JSONResponse({"ok": False}, status_code=401)
            session_key = self._device_sessions[dev_tok]["session_key"]
            tok = secrets.token_urlsafe(32)
            self._tokens.add(tok)
            self._token_keys[tok] = session_key
            self._aes_key(session_key)
            if self._connect_callback:
                self._connect_callback()
            asyncio.create_task(self.broadcast(
                {"type": "sys", "text": "Known device reconnected automatically."}
            ))
            return JSONResponse({"ok": True, "token": tok, "key": session_key})

        # Command endpoint (encrypted or plain)
        @app.post("/api/command")
        async def command(req: Request):
            if not _auth(req):
                return JSONResponse({"error": "Unauthorized"}, status_code=401)
            body = await req.json()
            token = req.headers.get("authorization", "").removeprefix("Bearer ").strip()
            enc = body.get("enc", "")
            if enc:
                text = self._decrypt(token, enc)
                if text is None:
                    return JSONResponse({"error": "Decryption failed"}, status_code=400)
            else:
                text = (body.get("text") or "").strip()
            if text:
                await self._command_queue.put(text)
                if self._wake_callback:
                    self._wake_callback()
            return JSONResponse({"ok": True})

        # Wake endpoint
        @app.post("/api/wake")
        async def wake_ep(req: Request):
            if not _auth(req):
                return JSONResponse({"error": "Unauthorized"}, status_code=401)
            if self._wake_callback:
                self._wake_callback()
            return JSONResponse({"ok": True})

        # ========================================================================
        # ENHANCED API ENDPOINTS FOR ALL DESKTOP FEATURES
        # ========================================================================

        # Action endpoint - execute any desktop action via API
        @app.post("/api/action/{action_name}")
        async def execute_action(action_name: str, req: Request):
            """
            Execute any desktop action via API.
            
            Request body should contain parameters for the action.
            Example: {"query": "Python tutorial", "mode": "search"}
            """
            if not _auth(req):
                return JSONResponse({"error": "Unauthorized"}, status_code=401)
            
            try:
                body = await req.json()
            except Exception:
                body = {}
            
            # Check if action exists
            if action_name not in self._action_modules:
                return JSONResponse(
                    {"error": f"Action '{action_name}' not found", "available": list(self._action_modules.keys())},
                    status_code=404
                )
            
            # Execute the action
            try:
                action_func = self._action_modules[action_name]
                # Most actions expect: parameters, response=None, player=None, session_memory=None
                result = action_func(
                    parameters=body,
                    response=None,
                    player=None,
                    session_memory=None
                )
                return JSONResponse({"ok": True, "result": result})
            except Exception as e:
                return JSONResponse(
                    {"ok": False, "error": str(e), "action": action_name},
                    status_code=500
                )

        # File upload endpoint
        if _UPLOAD_OK:
            @app.post("/api/upload")
            async def upload_file(req: Request, file: UploadFile = FastAPIFile(...)):
                if not _auth(req):
                    return JSONResponse({"error": "Unauthorized"}, status_code=401)

                safe = self._safe_filename(file.filename or "upload")
                dest = self._uploads_dir / safe
                stem, suffix = Path(safe).stem, Path(safe).suffix
                counter = 1
                while dest.exists():
                    dest = self._uploads_dir / f"{stem}_{counter}{suffix}"
                    counter += 1

                size = 0
                max_bytes = MAX_UPLOAD_MB * 1024 * 1024
                try:
                    with open(dest, "wb") as fout:
                        while True:
                            chunk = await file.read(65536)
                            if not chunk:
                                break
                            size += len(chunk)
                            if size > max_bytes:
                                fout.close()
                                dest.unlink(missing_ok=True)
                                return JSONResponse(
                                    {"error": f"File too large (max {MAX_UPLOAD_MB} MB)"},
                                    status_code=413,
                                )
                            fout.write(chunk)
                except Exception as exc:
                    try:
                        dest.unlink(missing_ok=True)
                    except Exception:
                        pass
                    return JSONResponse({"error": str(exc)}, status_code=500)

                asyncio.create_task(self.broadcast({
                    "type": "file_received",
                    "name": dest.name,
                    "size": size,
                    "saved_to": str(self._uploads_dir),
                }))
                return JSONResponse({"ok": True, "name": dest.name, "size": size, "path": str(dest)})
        
        @app.post("/api/upload")
        async def upload_unavailable(req: Request):
            return JSONResponse(
                {"error": "File uploads require: pip install python-multipart"},
                status_code=503,
            )

        # List uploaded files
        @app.get("/api/files")
        async def list_files(req: Request):
            if not _auth(req):
                return JSONResponse({"error": "Unauthorized"}, status_code=401)
            files = []
            try:
                for f in sorted(
                    (p for p in self._uploads_dir.iterdir() if p.is_file()),
                    key=lambda p: p.stat().st_mtime,
                    reverse=True,
                ):
                    files.append({"name": f.name, "size": f.stat().st_size, "path": str(f)})
            except Exception:
                pass
            return JSONResponse({"files": files})

        # Download file
        @app.get("/uploads/{filename}")
        async def download_file(filename: str, token: str = ""):
            tok = token.strip()
            if not tok or tok not in self._tokens:
                return JSONResponse({"error": "Unauthorized"}, status_code=401)
            safe = re.sub(r'[/\\]', '', filename)
            path = self._uploads_dir / safe
            if not path.exists() or not path.is_file():
                return JSONResponse({"error": "Not found"}, status_code=404)
            return FileResponse(str(path), filename=safe)

        # WebSocket for real-time communication
        @app.websocket("/ws")
        async def ws_ep(websocket: WebSocket, token: str = ""):
            tok = token.strip()
            if not tok or tok not in self._tokens:
                await websocket.close(code=4001)
                return
            await websocket.accept()
            self._clients.add(websocket)
            for entry in self._history[-50:]:
                try:
                    await websocket.send_json(entry)
                except Exception:
                    break
            try:
                while True:
                    data = await websocket.receive_json()
                    if data.get("type") == "command":
                        enc = data.get("enc", "")
                        t = self._decrypt(tok, enc) if enc else (data.get("text") or "").strip()
                        if t:
                            await self._command_queue.put(t)
                            if self._wake_callback:
                                self._wake_callback()
            except WebSocketDisconnect:
                pass
            finally:
                self._clients.discard(websocket)

        # Phone audio WebSocket
        @app.websocket("/ws/phone-audio")
        async def phone_audio_ws(websocket: WebSocket, token: str = ""):
            tok = token.strip()
            if not tok or tok not in self._tokens:
                await websocket.close(code=4001)
                return
            await websocket.accept()
            asyncio.create_task(self.broadcast(
                {"type": "sys", "text": "Phone microphone live."}
            ))
            try:
                while True:
                    data = await websocket.receive_bytes()
                    try:
                        self._phone_audio_queue.put_nowait(
                            {"data": data, "mime_type": "audio/pcm"}
                        )
                    except asyncio.QueueFull:
                        pass
            except WebSocketDisconnect:
                pass
            finally:
                asyncio.create_task(self.broadcast(
                    {"type": "sys", "text": "Phone microphone stopped."}
                ))

        # Get available actions
        @app.get("/api/actions")
        async def get_actions(req: Request):
            if not _auth(req):
                return JSONResponse({"error": "Unauthorized"}, status_code=401)
            return JSONResponse({
                "actions": list(self._action_modules.keys()),
                "count": len(self._action_modules)
            })

        # Get action info
        @app.get("/api/action/{action_name}/info")
        async def get_action_info(action_name: str, req: Request):
            if not _auth(req):
                return JSONResponse({"error": "Unauthorized"}, status_code=401)
            
            if action_name not in self._action_modules:
                return JSONResponse({"error": "Action not found"}, status_code=404)
            
            # Try to get docstring
            func = self._action_modules[action_name]
            doc = getattr(func, "__doc__", "No description available")
            
            return JSONResponse({
                "name": action_name,
                "description": doc,
                "available": True
            })

        # System status
        @app.get("/api/status")
        async def get_status(req: Request):
            if not _auth(req):
                return JSONResponse({"error": "Unauthorized"}, status_code=401)
            return JSONResponse({
                "status": "running",
                "connected_clients": len(self._clients),
                "actions_loaded": len(self._action_modules),
                "upload_dir": str(self._uploads_dir)
            })

        return app

    def _safe_filename(self, raw: str) -> str:
        name = Path(raw).name
        name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', '_', name).strip(". ")
        return name or "upload"

    async def serve(self) -> None:
        if not _DEPS_OK:
            print("[Dashboard] fastapi/uvicorn not installed - dashboard disabled.")
            print("[Dashboard] Run: pip install fastapi 'uvicorn[standard]' cryptography")
            return

        # Set IP
        self._ip = self._local_ip()

        cfg = uvicorn.Config(
            self.app, host="0.0.0.0", port=PORT, log_level="warning",
            log_config=None, access_log=False,
        )

        print(f"[Dashboard] http://{self._ip}:{PORT}")
        print(f"[Dashboard] Enhanced API Server - All desktop features available!")
        print(f"[Dashboard] Loaded actions: {list(self._action_modules.keys())}")
        print("[Dashboard] Press 'Mobile Connect' in Brahma UI to get the QR code.")
        await uvicorn.Server(cfg).serve()

    def _local_ip(self) -> str:
        """Return the best LAN-facing IPv4 address."""
        try:
            # Try to get a non-localhost IP
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.settimeout(0.5)
            try:
                s.connect(("8.8.8.8", 80))
                ip = s.getsockname()[0]
                s.close()
                if ip and ip != "127.0.0.1":
                    return ip
            except:
                pass
            s.close()
        except Exception:
            pass
        return "127.0.0.1"


# Create a singleton instance
server_instance = EnhancedDashboardServer()

# For backward compatibility
DashboardServer = EnhancedDashboardServer
